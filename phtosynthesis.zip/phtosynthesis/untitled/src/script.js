let video = document.getElementById("video");
let startCameraBtn = document.getElementById("startCamera");
let startRecordBtn = document.getElementById("startRecord");
let stopRecordBtn = document.getElementById("stopRecord");
let downloadLink = document.getElementById("downloadLink");

let mediaRecorder;
let recordedChunks = [];

let stream;

// Start Camera
startCameraBtn.onclick = async () => {
    try {
        stream = await navigator.mediaDevices.getUserMedia({
            video: true,
            audio: true
        });
        video.srcObject = stream;
    } catch (err) {
        alert("Camera access denied!");
    }
};

// Start Recording
startRecordBtn.onclick = () => {
    recordedChunks = [];
    mediaRecorder = new MediaRecorder(stream);

    mediaRecorder.ondataavailable = e => {
        if (e.data.size > 0) {
            recordedChunks.push(e.data);
        }
    };

    mediaRecorder.onstop = () => {
        let blob = new Blob(recordedChunks, { type: "video/webm" });
        let url = URL.createObjectURL(blob);

        downloadLink.href = url;
        downloadLink.download = "recorded_video.webm";
        downloadLink.style.display = "block";
        downloadLink.innerText = "Download Video";
    };

    mediaRecorder.start();
};

// Stop Recording
stopRecordBtn.onclick = () => {
    mediaRecorder.stop();
};