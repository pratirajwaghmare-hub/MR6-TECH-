 /* 

  
     slidebar start project


     */

     $(document).ready(function(){
  
  $('.acto').click(function(){
    $('.offscreen-nav').toggleClass('toggle-nav');
  });
  
});

    /* 

  
     slidebar end project


     */
    





const vid        = document.getElementById('vid');
const bgCanvas   = document.getElementById('bgCanvas');
const fxCanvas   = document.getElementById('fxCanvas');
const drawCanvas = document.getElementById('drawCanvas');
const bgCtx      = bgCanvas.getContext('2d');
const fxCtx      = fxCanvas.getContext('2d');
const drCtx      = drawCanvas.getContext('2d');

// UI refs
const topbar    = document.getElementById('topbar');
const hudEl     = document.getElementById('hud');
const helpEl    = document.getElementById('help');
const toast     = document.getElementById('toast');
const clearBtn  = document.getElementById('clearBtn');
const modeStripe = document.getElementById('modeStripe');
const gestDot   = document.getElementById('gestDot');
const gestLabel = document.getElementById('gestLabel');
const camDot    = document.getElementById('camDot');
const fpsVal    = document.getElementById('fpsVal');
const handsVal  = document.getElementById('handsVal');

// ── State ─────────────────────────────────────────────────
let W = 0, H = 0;
let mode = 'play';
let hands = [];        // current landmarks
let prevHands = [];
let handVel  = 0;
let time = 0;
let lastT = performance.now();
let fps = 0, fpsCounter = 0, fpsLast = performance.now();

// Particles & ripples
let particles = [];
let ripples = [];

// Drawing
let drawPaths = [];        // [ [{x,y,p}, ...], ... ]
let activePath = null;
let isDrawing  = false;
let drawColor  = 0;        // hue cycle

// Pinch state
let pinchWas = [false, false];

// Audio
let audioCtx = null;
let humOsc = null, humGain = null;

// Matrix rain
const FONT_SIZE = 15;
let matCols = [], maxCols = 0;

// Toast timer
let toastTimer = null;

// Glow palette – per mode
const MODES = {
  play:      { accent:'#7cffc4', accent2:'#ff6bca', stripe:'linear-gradient(90deg,#7cffc4,#6bb5ff)' },
  drawshape: { accent:'#ff6bca', accent2:'#ffb86c', stripe:'linear-gradient(90deg,#ff6bca,#ffb86c)' },
  write:     { accent:'#6bb5ff', accent2:'#b8aaff', stripe:'linear-gradient(90deg,#6bb5ff,#b8aaff)' },
};

const FINGER_TIPS = [4, 8, 12, 16, 20];

// Help text per mode
const HELP = {
  play: {
    title: 'Play Mode',
    tips: ['Pinch thumb + index to fire shockwave', 'Use both hands for lightning arcs', 'Sway fast to energize the rain'],
  },
  drawshape: {
    title: 'Shape Mode',
    tips: ['Hold both hands close, fingers open = ♥ Heart', 'Peace sign (2 fingers) = ✌ displayed', 'Fist both hands = ⭐ Star burst'],
  },
  write: {
    title: 'Write Mode',
    tips: ['Point with index finger to draw', 'Close fist to lift the pen', 'Shake open hand rapidly to clear'],
  },
};

// ── Resize ────────────────────────────────────────────────
function resize() {
  W = window.innerWidth;
  H = window.innerHeight;
  [bgCanvas, fxCanvas, drawCanvas].forEach(c => { c.width = W; c.height = H; });
  maxCols = Math.floor(W / FONT_SIZE);
  matCols = Array.from({length: maxCols}, () => Math.random() * (H / FONT_SIZE));
}
window.addEventListener('resize', resize);
resize();

// ── Map landmark to canvas ────────────────────────────────
function lm(pt) {
  // MediaPipe x is already mirrored-aware; canvas is CSS-flipped so coords match
  return { x: pt.x * W, y: pt.y * H };
}
function dist(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}
function ndist(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);  // normalised-space distance
}

// ── Toast ─────────────────────────────────────────────────
function showToast(text, color) {
  toast.textContent = text;
  toast.style.color = color || MODES[mode].accent;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 1600);
}

// ── Gesture label update ──────────────────────────────────
function setGesture(label, active) {
  gestLabel.textContent = label;
  gestDot.classList.toggle('on', !!active);
}

// ── Audio ─────────────────────────────────────────────────
function initAudio() {
  try {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    humOsc  = audioCtx.createOscillator();
    humGain = audioCtx.createGain();
    const rev = audioCtx.createConvolver();
    humOsc.type = 'sine';
    humOsc.frequency.value = 110;
    humGain.gain.value = 0;
    humOsc.connect(humGain);
    humGain.connect(audioCtx.destination);
    humOsc.start();
  } catch(e) { console.warn('Audio init failed', e); }
}

function playZap(freq = 700) {
  if (!audioCtx) return;
  const osc  = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.type = 'sawtooth';
  osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
  osc.frequency.exponentialRampToValueAtTime(30, audioCtx.currentTime + 0.12);
  gain.gain.setValueAtTime(0.35, audioCtx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.12);
  osc.connect(gain);
  gain.connect(audioCtx.destination);
  osc.start();
  osc.stop(audioCtx.currentTime + 0.15);
}

function playPop(freq = 440) {
  if (!audioCtx) return;
  const osc  = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.type = 'sine';
  osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
  osc.frequency.exponentialRampToValueAtTime(freq * 0.5, audioCtx.currentTime + 0.08);
  gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.12);
  osc.connect(gain);
  gain.connect(audioCtx.destination);
  osc.start();
  osc.stop(audioCtx.currentTime + 0.15);
}

function updateHum() {
  if (!audioCtx || !humGain) return;
  if (hands.length < 2) { humGain.gain.setTargetAtTime(0, audioCtx.currentTime, 0.1); return; }
  const d = ndist(hands[0][8], hands[1][8]);
  const intensity = Math.max(0, 1 - d * 2.2);
  humOsc.frequency.setTargetAtTime(80 + intensity * 280, audioCtx.currentTime, 0.15);
  humGain.gain.setTargetAtTime(intensity * 0.12, audioCtx.currentTime, 0.1);
}

// ── Particles ─────────────────────────────────────────────
function spawnParticles(x, y, color, n = 10) {
  for (let i = 0; i < n; i++) {
    const angle = Math.random() * Math.PI * 2;
    const spd   = Math.random() * 6 + 2;
    particles.push({
      x, y,
      vx: Math.cos(angle) * spd,
      vy: Math.sin(angle) * spd,
      life: 1,
      size: Math.random() * 4 + 1.5,
      color,
    });
  }
}

function spawnRipple(x, y, color) {
  ripples.push({ x, y, r: 0, maxR: 160 + Math.random() * 80, life: 1, color });
}

// ── Background: Matrix rain ────────────────────────────────
function drawBackground() {
  // Fade trail
  bgCtx.globalCompositeOperation = 'destination-out';
  const fade = 0.12 + Math.min(handVel * 12, 0.55);
  bgCtx.fillStyle = `rgba(0,0,0,${fade})`;
  bgCtx.fillRect(0, 0, W, H);
  bgCtx.globalCompositeOperation = 'source-over';

  const hue = (time * 20) % 360;
  bgCtx.fillStyle = `hsl(${hue},100%,55%)`;
  bgCtx.font = FONT_SIZE + 'px DM Mono, monospace';

  const speedMult = 0.6 + handVel * 60;
  for (let i = 0; i < maxCols; i++) {
    if (Math.random() > 0.93) {
      const char = String.fromCharCode(0x30A0 + Math.random() * 96);
      bgCtx.fillText(char, i * FONT_SIZE, matCols[i] * FONT_SIZE);
    }
    matCols[i] += Math.random() * speedMult;
    if (matCols[i] * FONT_SIZE > H && Math.random() > 0.9) matCols[i] = 0;
  }
}

// ── FX canvas: skeleton, particles, ripples ───────────────
function drawFX() {
  // Fade main fx layer
  fxCtx.globalCompositeOperation = 'destination-out';
  fxCtx.fillStyle = 'rgba(0,0,0,0.18)';
  fxCtx.fillRect(0, 0, W, H);
  fxCtx.globalCompositeOperation = 'screen';

  // Particles
  for (let i = particles.length - 1; i >= 0; i--) {
    const p = particles[i];
    p.x  += p.vx; p.y  += p.vy;
    p.vy += 0.15;
    p.life -= 0.022;
    if (p.life <= 0) { particles.splice(i, 1); continue; }
    fxCtx.beginPath();
    fxCtx.arc(p.x, p.y, p.size * p.life, 0, Math.PI * 2);
    fxCtx.fillStyle = p.color;
    fxCtx.globalAlpha = p.life;
    fxCtx.fill();
  }

  // Ripples
  for (let i = ripples.length - 1; i >= 0; i--) {
    const r = ripples[i];
    r.r   += (r.maxR - r.r) * 0.12;
    r.life -= 0.025;
    if (r.life <= 0) { ripples.splice(i, 1); continue; }
    fxCtx.beginPath();
    fxCtx.arc(r.x, r.y, r.r, 0, Math.PI * 2);
    fxCtx.strokeStyle = r.color;
    fxCtx.lineWidth   = 3.5 * r.life;
    fxCtx.globalAlpha = r.life * 0.8;
    fxCtx.stroke();
    // inner ring
    fxCtx.beginPath();
    fxCtx.arc(r.x, r.y, r.r * 0.55, 0, Math.PI * 2);
    fxCtx.globalAlpha = r.life * 0.35;
    fxCtx.stroke();
  }

  fxCtx.globalAlpha = 1;
  fxCtx.globalCompositeOperation = 'source-over';

  // ── Per-mode hand rendering ──────────────────────────────
  if (!hands.length) return;

  if (mode === 'play') drawPlayMode();
}

// ── PLAY MODE ─────────────────────────────────────────────
function drawPlayMode() {
  hands.forEach((hand, hi) => {
    const hue = (time * 40 + hi * 160) % 360;
    const glowColor = `hsl(${hue},100%,60%)`;

    // Skeleton connectors
    fxCtx.save();
    fxCtx.shadowBlur = 10;
    fxCtx.shadowColor = glowColor;
    HAND_CONNECTIONS.forEach(([a, b]) => {
      const pa = lm(hand[a]);
      const pb = lm(hand[b]);
      fxCtx.beginPath();
      fxCtx.moveTo(pa.x, pa.y);
      fxCtx.lineTo(pb.x, pb.y);
      fxCtx.strokeStyle = glowColor;
      fxCtx.lineWidth = 2;
      fxCtx.globalAlpha = 0.7;
      fxCtx.stroke();
    });

    // Fingertip blobs
    FINGER_TIPS.forEach((ti, idx) => {
      const pt = lm(hand[ti]);
      const tipHue = (hue + idx * 30) % 360;
      fxCtx.beginPath();
      fxCtx.arc(pt.x, pt.y, 6, 0, Math.PI * 2);
      fxCtx.fillStyle = `hsl(${tipHue},100%,70%)`;
      fxCtx.shadowBlur = 18;
      fxCtx.shadowColor = `hsl(${tipHue},100%,60%)`;
      fxCtx.globalAlpha = 1;
      fxCtx.fill();
      // trail particle burst (random)
      if (Math.random() > 0.7) spawnParticles(pt.x, pt.y, `hsl(${tipHue},100%,65%)`, 1);
    });
    fxCtx.restore();
  });

  // Two-hand interactions
  if (hands.length >= 2) {
    FINGER_TIPS.forEach((ti, idx) => {
      const p1 = lm(hands[0][ti]);
      const p2 = lm(hands[1][ti]);
      const d  = dist(p1, p2);
      const hue1 = (time * 40 + idx * 40) % 360;

      // Gradient line
      const grad = fxCtx.createLinearGradient(p1.x, p1.y, p2.x, p2.y);
      grad.addColorStop(0, `hsl(${hue1},100%,60%)`);
      grad.addColorStop(1, `hsl(${(hue1+120)%360},100%,60%)`);
      fxCtx.beginPath();
      fxCtx.moveTo(p1.x, p1.y);
      fxCtx.lineTo(p2.x, p2.y);
      fxCtx.strokeStyle = grad;
      fxCtx.lineWidth = 3.5;
      fxCtx.globalAlpha = 0.6;
      fxCtx.shadowBlur = 12;
      fxCtx.shadowColor = `hsl(${hue1},100%,60%)`;
      fxCtx.stroke();

      // Lightning when close
      if (d < 140 && Math.random() > 0.45) {
        fxCtx.beginPath();
        fxCtx.moveTo(p1.x, p1.y);
        const mx = (p1.x + p2.x)/2 + (Math.random()-0.5)*60;
        const my = (p1.y + p2.y)/2 + (Math.random()-0.5)*60;
        fxCtx.lineTo(mx, my);
        fxCtx.lineTo(p2.x, p2.y);
        fxCtx.strokeStyle = '#ffffff';
        fxCtx.lineWidth = 1.5;
        fxCtx.globalAlpha = 0.9;
        fxCtx.shadowBlur = 25;
        fxCtx.shadowColor = `hsl(${hue1},100%,80%)`;
        fxCtx.stroke();
      }
    });

    // Orbiting mandala
    const allTips = [...FINGER_TIPS.map(t=>lm(hands[0][t])), ...FINGER_TIPS.map(t=>lm(hands[1][t]))];
    const cx = allTips.reduce((s,p)=>s+p.x,0)/10;
    const cy = allTips.reduce((s,p)=>s+p.y,0)/10;
    fxCtx.save();
    fxCtx.translate(cx, cy);
    fxCtx.rotate(time * 0.6);
    fxCtx.beginPath();
    for (let i=0; i<10; i++) {
      const a = { x: allTips[i].x-cx, y: allTips[i].y-cy };
      const b = { x: allTips[(i+3)%10].x-cx, y: allTips[(i+3)%10].y-cy };
      fxCtx.moveTo(a.x, a.y);
      fxCtx.lineTo(b.x, b.y);
    }
    fxCtx.strokeStyle = 'rgba(255,255,255,0.15)';
    fxCtx.lineWidth = 1;
    fxCtx.globalAlpha = 1;
    fxCtx.shadowBlur = 0;
    fxCtx.stroke();
    fxCtx.restore();
  }

  fxCtx.globalAlpha = 1;
  fxCtx.shadowBlur = 0;
}

// ── DRAW CANVAS: Write mode paths ────────────────────────
function strokePath(pts, hue) {
  if (pts.length < 2) return;
  drCtx.beginPath();
  drCtx.moveTo(pts[0].x, pts[0].y);
  for (let i = 1; i < pts.length; i++) {
    const mx = (pts[i-1].x + pts[i].x) / 2;
    const my = (pts[i-1].y + pts[i].y) / 2;
    drCtx.quadraticCurveTo(pts[i-1].x, pts[i-1].y, mx, my);
  }
  drCtx.lineTo(pts[pts.length-1].x, pts[pts.length-1].y);
  drCtx.strokeStyle = `hsl(${hue}, 100%, 65%)`;
  drCtx.lineWidth   = 4.5;
  drCtx.lineCap     = 'round';
  drCtx.lineJoin    = 'round';
  drCtx.shadowBlur  = 16;
  drCtx.shadowColor = `hsl(${hue}, 100%, 55%)`;
  drCtx.stroke();
  drCtx.shadowBlur  = 0;
}

function renderDrawPaths() {
  // CRITICAL: clear the draw canvas every frame so clearCanvas() takes immediate effect
  drCtx.clearRect(0, 0, W, H);

  // Completed paths — fixed hue per path so colour stays stable
  drawPaths.forEach((pts, pi) => {
    strokePath(pts, (pi * 47) % 360);
  });

  // In-progress path
  if (activePath && activePath.length >= 2) {
    strokePath(activePath, (drawPaths.length * 47) % 360);
  }
}

// ── DRAW SHAPE: Heart ────────────────────────────────────
// Uses the standard parametric heart: x=16sin^3(t), y=13cos(t)-5cos(2t)-2cos(3t)-cos(4t)
function drawHeart(x, y, size) {
  fxCtx.save();
  fxCtx.globalCompositeOperation = 'source-over';
  fxCtx.translate(x, y);
  fxCtx.globalAlpha = 1;

  const scale = (size / 17) * (1 + Math.sin(time * 5) * 0.05);
  const steps = 120;

  fxCtx.beginPath();
  for (let i = 0; i <= steps; i++) {
    const t  = (i / steps) * Math.PI * 2;
    const hx =  16 * Math.pow(Math.sin(t), 3);
    const hy = -(13 * Math.cos(t) - 5 * Math.cos(2*t) - 2 * Math.cos(3*t) - Math.cos(4*t));
    const px = hx * scale * size * 0.058;
    const py = hy * scale * size * 0.058;
    i === 0 ? fxCtx.moveTo(px, py) : fxCtx.lineTo(px, py);
  }
  fxCtx.closePath();

  const g = fxCtx.createRadialGradient(0, -size*0.15, 0, 0, size*0.1, size*1.1);
  g.addColorStop(0,   '#ff9de0');
  g.addColorStop(0.4, '#ff3399');
  g.addColorStop(1,   '#99003d');
  fxCtx.fillStyle = g;
  fxCtx.shadowBlur = 55;
  fxCtx.shadowColor = '#ff3399';
  fxCtx.fill();

  fxCtx.strokeStyle = 'rgba(255,180,220,0.9)';
  fxCtx.lineWidth = 2.5;
  fxCtx.shadowBlur = 25;
  fxCtx.shadowColor = '#ff6bca';
  fxCtx.stroke();

  // Inner highlight shimmer
  fxCtx.beginPath();
  for (let i = 0; i <= steps; i++) {
    const t  = (i / steps) * Math.PI * 2;
    const hx =  16 * Math.pow(Math.sin(t), 3);
    const hy = -(13 * Math.cos(t) - 5 * Math.cos(2*t) - 2 * Math.cos(3*t) - Math.cos(4*t));
    const px = hx * scale * size * 0.058;
    const py = hy * scale * size * 0.058;
    i === 0 ? fxCtx.moveTo(px, py) : fxCtx.lineTo(px, py);
  }
  fxCtx.closePath();
  fxCtx.clip();
  const shine = fxCtx.createRadialGradient(-size*0.2, -size*0.3, 0, -size*0.1, -size*0.1, size*0.55);
  shine.addColorStop(0,   'rgba(255,255,255,0.38)');
  shine.addColorStop(0.6, 'rgba(255,255,255,0.06)');
  shine.addColorStop(1,   'rgba(255,255,255,0)');
  fxCtx.fillStyle = shine;
  fxCtx.shadowBlur = 0;
  fxCtx.fill();

  fxCtx.restore();
}

// Peace/victory sign shape
function drawPeace(x, y, size, color) {
  fxCtx.save();
  fxCtx.globalCompositeOperation = 'source-over';
  fxCtx.translate(x, y);
  fxCtx.beginPath();
  fxCtx.arc(0, 0, size, 0, Math.PI * 2);
  fxCtx.strokeStyle = color;
  fxCtx.lineWidth = 4;
  fxCtx.shadowBlur = 30;
  fxCtx.shadowColor = color;
  fxCtx.stroke();
  // Lines inside
  fxCtx.beginPath();
  fxCtx.moveTo(0, -size);
  fxCtx.lineTo(0, size);
  fxCtx.moveTo(0, 0);
  fxCtx.lineTo(-size * 0.7, size * 0.7);
  fxCtx.moveTo(0, 0);
  fxCtx.lineTo(size * 0.7, size * 0.7);
  fxCtx.stroke();
  fxCtx.restore();
}

// Star burst
function drawStarBurst(x, y, size, color) {
  const spikes = 8;
  fxCtx.save();
  fxCtx.translate(x, y);
  fxCtx.rotate(time * 1.5);
  fxCtx.beginPath();
  for (let i = 0; i < spikes * 2; i++) {
    const angle = (i * Math.PI) / spikes;
    const r = i % 2 === 0 ? size : size * 0.4;
    const xi = Math.cos(angle) * r;
    const yi = Math.sin(angle) * r;
    i === 0 ? fxCtx.moveTo(xi, yi) : fxCtx.lineTo(xi, yi);
  }
  fxCtx.closePath();
  const g2 = fxCtx.createRadialGradient(0, 0, 0, 0, 0, size);
  g2.addColorStop(0, '#fff');
  g2.addColorStop(0.4, color);
  g2.addColorStop(1, 'transparent');
  fxCtx.fillStyle = g2;
  fxCtx.shadowBlur = 40;
  fxCtx.shadowColor = color;
  fxCtx.fill();
  fxCtx.restore();
}

// ── GESTURE DETECTION ─────────────────────────────────────
let heartWas  = false;
let peaceWas  = false;
let fistBothWas = false;

// Shake detection state
let shakeVel = [0, 0];
let shakePrev = [null, null];
let shakeAccum = 0;

function detectGestures() {
  if (!hands.length) { setGesture('No hands detected', false); return; }

  if (mode === 'play') gesturePlay();
  if (mode === 'drawshape') gestureShape();
  if (mode === 'write') gestureWrite();
}

function gesturePlay() {
  hands.forEach((hand, hi) => {
    const thumb = hand[4];
    const index = hand[8];
    const d = ndist(thumb, index);
    const pinching = d < 0.055;

    if (pinching && !pinchWas[hi]) {
      const mid = lm({ x:(thumb.x+index.x)/2, y:(thumb.y+index.y)/2 });
      spawnRipple(mid.x, mid.y, MODES.play.accent);
      spawnParticles(mid.x, mid.y, MODES.play.accent, 18);
      playZap(600 + hi * 120);
      showToast('⚡ Pinch', MODES.play.accent);
      setGesture('Pinch detected!', true);
    }
    if (!pinching && pinchWas[hi]) setGesture('Open', false);
    pinchWas[hi] = pinching;
  });

  if (hands[0]) {
    const sp = ndist(hands[0][8], hands[0][20]);
    setGesture(sp > 0.18 ? '✋ Open hand' : '✊ Fist', sp > 0.18);
  }
}

function gestureShape() {
  if (hands.length < 2) {
    setGesture('Show both hands', false);
    heartWas = peaceWas = fistBothWas = false;
    return;
  }

  const palm1 = hands[0][0], palm2 = hands[1][0];
  const palmD  = ndist(palm1, palm2);
  const sp1 = ndist(hands[0][8], hands[0][20]);
  const sp2 = ndist(hands[1][8], hands[1][20]);

  // ♥ Heart: palms close + fingers open
  const isHeart = palmD < 0.35 && sp1 > 0.09 && sp2 > 0.09;
  if (isHeart) {
    if (!heartWas) { playPop(880); showToast('♥ Heart', MODES.drawshape.accent); }
    heartWas = true;
    const hx = (palm1.x + palm2.x)/2 * W;
    const hy = (palm1.y + palm2.y)/2 * H - 55;
    drawHeart(hx, hy, 60);
    setGesture('♥ Heart detected', true);
    return;
  }
  heartWas = false;

  // ✌ Peace: index + middle extended, ring + pinky curled — detect by tip distances
  function isPeaceSign(hand) {
    // index and middle extended: tips far from palm; ring and pinky curled: tips close to palm
    const palmPt = hand[0];
    const idx = ndist(hand[8], palmPt);
    const mid = ndist(hand[12], palmPt);
    const rng = ndist(hand[16], palmPt);
    const pnk = ndist(hand[20], palmPt);
    const thmb = ndist(hand[4], palmPt);
    return idx > 0.18 && mid > 0.18 && rng < 0.16 && pnk < 0.16;
  }
  const isPeace1 = isPeaceSign(hands[0]);
  const isPeace2 = isPeaceSign(hands[1]);
  if (isPeace1 || isPeace2) {
    if (!peaceWas) { playPop(660); showToast('✌ Peace', MODES.drawshape.accent2); }
    peaceWas = true;
    const hand = isPeace1 ? hands[0] : hands[1];
    const hx = hand[0].x * W;
    const hy = hand[0].y * H - 80;
    drawPeace(hx, hy, 55 + Math.sin(time*4)*5, MODES.drawshape.accent2);
    setGesture('✌ Peace sign', true);
    return;
  }
  peaceWas = false;

  // ⭐ Fist both: both hands closed
  const fist1 = sp1 < 0.09;
  const fist2 = sp2 < 0.09;
  if (fist1 && fist2) {
    if (!fistBothWas) {
      playZap(300);
      showToast('💥 Star Burst!', '#ffb86c');
      spawnParticles((palm1.x+palm2.x)/2*W, (palm1.y+palm2.y)/2*H, '#ffb86c', 25);
    }
    fistBothWas = true;
    const cx = (palm1.x+palm2.x)/2 * W;
    const cy = (palm1.y+palm2.y)/2 * H;
    const sz = 50 + Math.sin(time * 3) * 8;
    drawStarBurst(cx, cy, sz, '#ffb86c');
    setGesture('💥 Star Burst', true);
    return;
  }
  fistBothWas = false;

  setGesture('Awaiting gesture…', false);
}

// Write mode: index tip pointing, fist to lift
let penDown = false;
function gestureWrite() {
  if (!hands.length) { penDown = false; isDrawing = false; setGesture('Show your hand', false); return; }

  const hand = hands[0];
  const palmPt = hand[0];

  // Extend index: index tip far from palm, middle/ring/pinky curled
  const idxDist  = ndist(hand[8], palmPt);
  const midDist  = ndist(hand[12], palmPt);
  const rngDist  = ndist(hand[16], palmPt);
  const thumbDist = ndist(hand[4], palmPt);

  // "Pen down": index extended AND others NOT
  const indexExtended = idxDist > 0.17;
  const othersBack    = midDist < 0.18 || rngDist < 0.15;  // Relaxed: some curl is fine
  // More reliable: just use spread of all fingers
  const spread = ndist(hand[8], hand[20]);
  const indexAlone = idxDist > 0.17 && ndist(hand[4], hand[8]) > 0.08; // thumb not pinching

  // Check pinch (thumb + index close) = lift pen
  const pinchLift = ndist(hand[4], hand[8]) < 0.06;

  if (pinchLift) {
    if (isDrawing) {
      if (activePath && activePath.length > 1) drawPaths.push(activePath);
      activePath = null;
      isDrawing  = false;
    }
    penDown = false;
    setGesture('✊ Pen up (pinch)', false);
    return;
  }

  if (indexAlone) {
    const tip = lm(hand[8]);
    if (!isDrawing) {
      activePath = [{ x: tip.x, y: tip.y }];
      isDrawing  = true;
    } else {
      // Only add if moved enough (avoid noise)
      const last = activePath[activePath.length - 1];
      if (Math.hypot(tip.x - last.x, tip.y - last.y) > 3) {
        activePath.push({ x: tip.x, y: tip.y });
      }
    }
    penDown = true;
    setGesture('✏️ Writing…', true);
    // Show index tip cursor
    drawIndexCursor(tip);
  } else {
    if (isDrawing && activePath && activePath.length > 1) {
      drawPaths.push(activePath);
    }
    activePath = null;
    isDrawing  = false;
    penDown    = false;
    setGesture('Point index finger to draw', false);
  }
}

function drawIndexCursor(tip) {
  fxCtx.save();
  fxCtx.globalCompositeOperation = 'source-over';
  const hue = (time * 80) % 360;
  fxCtx.beginPath();
  fxCtx.arc(tip.x, tip.y, 8, 0, Math.PI * 2);
  fxCtx.fillStyle = `hsl(${hue},100%,65%)`;
  fxCtx.shadowBlur = 20;
  fxCtx.shadowColor = `hsl(${hue},100%,60%)`;
  fxCtx.fill();
  // outer ring
  fxCtx.beginPath();
  fxCtx.arc(tip.x, tip.y, 16, 0, Math.PI * 2);
  fxCtx.strokeStyle = `hsl(${hue},100%,65%)`;
  fxCtx.lineWidth = 1.5;
  fxCtx.globalAlpha = 0.4;
  fxCtx.stroke();
  fxCtx.restore();
}

// ── SHAKE TO CLEAR ───────────────────────────────────────
// Strategy: open palm (4 fingers extended) + wrist X crosses left/right rapidly
let shakeHist     = [];
let shakeCooldown = 0;
let shakeProgress = 0; // 0-100, shown as visual progress hint

function isOpenPalm(hand) {
  // Fingers 2-5: tip must be above its PIP joint (finger pointing up/out)
  // Use Y-axis: in normalised space, smaller Y = higher on screen
  // Compare tip Y vs PIP Y — tip should be LESS (higher) than PIP when extended
  // Index=8 vs PIP=6, Middle=12 vs PIP=10, Ring=16 vs PIP=14, Pinky=20 vs PIP=18
  const pairs = [[8,6],[12,10],[16,14],[20,18]];
  let extended = 0;
  pairs.forEach(([tip, pip]) => {
    // tip landmark Y < pip landmark Y means finger is extended upward
    if (hand[tip].y < hand[pip].y) extended++;
  });
  return extended >= 3; // at least 3 of 4 fingers extended
}

function detectShake() {
  if (mode !== 'write' || !hands.length) {
    shakeHist = [];
    shakeProgress = 0;
    shakeCooldown = Math.max(0, shakeCooldown - 1);
    return;
  }

  if (shakeCooldown > 0) { shakeCooldown--; return; }

  const hand   = hands[0];
  const wristX = hand[0].x; // normalised 0..1

  // Gate: must show open palm
  if (!isOpenPalm(hand)) {
    // Decay history slowly so brief occlusion doesn't fully reset
    if (shakeHist.length > 0) shakeHist.shift();
    shakeProgress = Math.max(0, shakeProgress - 3);
    setGesture('✋ Open palm + shake to clear', false);
    return;
  }

  shakeHist.push(wristX);
  if (shakeHist.length > 30) shakeHist.shift();

  // Count direction reversals over the history window
  let reversals = 0;
  for (let i = 2; i < shakeHist.length; i++) {
    const d1 = shakeHist[i-1] - shakeHist[i-2];
    const d2 = shakeHist[i]   - shakeHist[i-1];
    // Only count meaningful movement changes (filter out jitter < 0.008)
    if (Math.abs(d1) > 0.008 && Math.abs(d2) > 0.008 && d1 * d2 < 0) {
      reversals++;
    }
  }

  // Map reversals to progress 0-100
  shakeProgress = Math.min(100, Math.round((reversals / 6) * 100));

  if (shakeProgress >= 40) {
    setGesture(`🌊 Shaking… ${shakeProgress}%`, true);
  } else {
    setGesture('✋ Shake open palm fast to clear', false);
  }

  // Trigger clear at 6+ reversals
  if (reversals >= 6) {
    clearCanvas();
    shakeHist     = [];
    shakeProgress = 0;
    shakeCooldown = 60; // 2s cooldown
  }
}

function clearCanvas() {
  drawPaths = [];
  activePath = null;
  isDrawing  = false;
  drCtx.clearRect(0, 0, W, H);
  playPop(330);
  showToast('🌊 Canvas cleared', MODES.write.accent);
  setGesture('Canvas cleared!', false);
}

// ── Velocity from landmark diff ───────────────────────────
function calcVelocity(cur, prev) {
  if (!prev || !prev.length || !cur || !cur.length) return 0;
  return ndist(cur[0][8], prev[0][8]);
}

// ── SHAKE RING UI UPDATE ─────────────────────────────────
const shakeRingEl  = document.getElementById('shakeRing');
const ringFillEl   = document.getElementById('ringFill');
const RING_TOTAL   = 157; // 2 * pi * 25

function updateShakeRing() {
  if (mode !== 'write') { shakeRingEl.classList.remove('visible'); return; }
  if (shakeProgress > 5) {
    shakeRingEl.classList.add('visible');
    const offset = RING_TOTAL - (RING_TOTAL * shakeProgress / 100);
    ringFillEl.style.strokeDashoffset = offset;
    // Colour shifts green->yellow->orange as progress builds
    const hue = 200 - shakeProgress * 1.5;
    ringFillEl.style.stroke = `hsl(${hue}, 100%, 65%)`;
    shakeRingEl.style.filter = shakeProgress > 60
      ? `drop-shadow(0 0 12px hsl(${hue},100%,55%))` : '';
  } else {
    shakeRingEl.classList.remove('visible');
    ringFillEl.style.strokeDashoffset = RING_TOTAL;
  }
}

// ── MAIN RENDER LOOP ──────────────────────────────────────
function renderLoop(ts) {
  requestAnimationFrame(renderLoop);

  const dt = (ts - lastT) / 1000;
  lastT = ts;
  time += dt;

  // FPS
  fpsCounter++;
  if (ts - fpsLast > 1000) {
    fps = fpsCounter;
    fpsCounter = 0;
    fpsLast = ts;
    fpsVal.textContent = fps;
    camDot.classList.toggle('on', fps > 5);
  }

  drawBackground();
  drawFX();

  // Write mode: draw paths on drawCanvas
  if (mode === 'write') {
    renderDrawPaths();
  } else {
    // Clear draw canvas when not in write mode
  }

  detectGestures();
  detectShake();
  updateShakeRing();
  updateHum();
  prevHands = hands;
}

// ── MODE SWITCH ───────────────────────────────────────────
const helpLines = [
  document.getElementById('helpLine1'),
  document.getElementById('helpLine2'),
  document.getElementById('helpLine3'),
];

function switchMode(newMode) {
  mode = newMode;
  pinchWas = [false, false];
  heartWas = peaceWas = fistBothWas = false;
  isDrawing = false; activePath = null;
  if (mode !== 'write') {
    drCtx.clearRect(0, 0, W, H);
    drawPaths = [];
  }

  // Update stripe color
  modeStripe.style.background = MODES[mode].stripe;

  // Update help
  const h = HELP[mode];
  document.getElementById('helpTitle').textContent = h.title;
  h.tips.forEach((t, i) => { if(helpLines[i]) helpLines[i].textContent = t; });

  // Clear button visibility
  clearBtn.classList.toggle('visible', mode === 'write');
}

document.querySelectorAll('.mode-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    switchMode(btn.dataset.mode);
  });
});

clearBtn.addEventListener('click', clearCanvas);

// ── MEDIAPIPE ────────────────────────────────────────────
async function initMediaPipe() {
  const mpHands = new Hands({ locateFile: f => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${f}` });
  mpHands.setOptions({
    maxNumHands: 2,
    modelComplexity: 1,
    minDetectionConfidence: 0.72,
    minTrackingConfidence: 0.72,
  });

  mpHands.onResults(results => {
    prevHands = hands;
    hands = results.multiHandLandmarks || [];
    handsVal.textContent = hands.length;
    handVel = calcVelocity(hands, prevHands);
  });

  // Request highest possible resolution from browser directly
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: {
        facingMode: 'user',
        width:  { ideal: 1920, min: 1280 },
        height: { ideal: 1080, min: 720  },
        frameRate: { ideal: 30, min: 24  },
      }
    });
    vid.srcObject = stream;
    await new Promise(r => vid.onloadedmetadata = r);
    vid.play();
  } catch(e) {
    console.warn('High-res camera failed, falling back', e);
  }

  const cam = new Camera(vid, {
    onFrame: async () => { await mpHands.send({ image: vid }); },
    width: 1920, height: 1080, facingMode: 'user',
  });
  cam.start();
}

// ── ENTRY POINT ──────────────────────────────────────────
document.getElementById('enterBtn').addEventListener('click', () => {
  document.getElementById('splash').classList.add('out');

  setTimeout(() => {
    topbar.classList.add('visible');
    hudEl.classList.add('visible');
    helpEl.classList.add('visible');
    modeStripe.classList.add('visible');
    modeStripe.style.background = MODES[mode].stripe;
    initAudio();
    initMediaPipe();
    requestAnimationFrame(renderLoop);
  }, 300);
});
function hell(){
  document.write('<section id="mySection" style="color:black; height:100vh; width:100%; background-image:url(https://tse1.mm.bing.net/th/id/OIP.pvHRBMGdVhCxbGBHbvwlGwHaEK?w=1366&h=768&rs=1&pid=ImgDetMain&o=7&rm=3); background-size:cover;">Hello World</section>');
}