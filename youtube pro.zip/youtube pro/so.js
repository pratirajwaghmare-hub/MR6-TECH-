function tech(){
document.write(`
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Youtube</title>
     <meta charset="UTF-8">
    <title>youtube clone</title>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Material Icons -->

    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" />
    <!-- CSS File -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Final - Youtube UI Clone</title>
	<style>
    *{
        margin:0px;
        padding:0px;
        box-sizing:border-box;
        background-color:#fff;
    } 
    body {
  font-family: 'Roboto', sans-serif;
}
/* header */

.material-icons {
  color: rgb(96, 96, 96);
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  position:fixed;
  top:0px;
  height: 70px;
  padding: 15px;
  background-color:#fff;
  z-index:999;
}

.header__left {
  position:relative;
  display: flex;
  align-items: center;
}

.header__left img {
  width: 100px;
  margin-left: 15px;
}

.header i {
  padding: 0 7px;
  cursor: pointer;
}

.header__search form {
  border: 1px solid #ddd;
  height: 35px;
  margin: 0;
  padding: 0;
  border-radius:20px;
  display: flex;
}

.header__search input {
  width: 500px;
  padding: 10px;
  margin: 0;
  border-radius:20px;
  border: none;
  height: 100%;
}

.header__search button {
  padding: 0;
  margin: 0;
  height: 100%;
  border: none;
  border-radius:0 20px 20px 0;
  background-color:none;
}
   @charset "UTF-8";
@import url("https://fonts.googleapis.com/css2?family=Manrope:wght@300;400;500;600&display=swap");
:root {
  --body-font: "Manrope", sans-serif;
  --body-color: #b3b3b3;
  --body-bg-color: #f2f2f2;
  --theme-bg-color: #fafafa;
  --border-color: #efefef;
  --logo-color: #f13a2f;
  --main-color: #808080;
  --header-bg-color: #fff;
}

.dark-mode {
  --body-bg-color: #1e222b;
  --theme-bg-color: #212835;
  --border-color: #393f50;
  --header-bg-color: #323a4b;
  --main-color: #fefffd;
  --body-color: #dddee0;
}

* {
  outline: none;
  box-sizing: border-box;
}

img {
  max-width: 100%;
}

html {
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
}




.header {
  height: 90px;
  width: 100%;
  border-bottom: 1px solid var(--border-color);
  display: flex;
  background-color: var(--header-bg-color);
  align-items: center;
  padding: 0 25px;
  color: var(--body-color);
  font-size: 15px;
}

.header-left {
  display: flex;
  align-items: center;
}
.header-left svg {
  width: 22px;
  margin-right: 25px;
  flex-shrink: 0;
}

.logo {
  width: 34px;
  height: 34px;
  border: 5px solid var(--logo-color);
  border-radius: 50%;
  flex-shrink: 0;
}

.header-menu {
  display: flex;
  align-items: center;
  cursor: pointer;
  margin-left: auto;
  height: 100;
  padding: 0 15px;
}

.menu-item:hover {
  color: var(--logo-color);
}
.menu-item:not(:last-child) {
  margin-right: 20px;
}

.user-settings {
  display: flex;
  align-items: center;
  margin-left: auto;
  flex-shrink: 0;
}
.user-settings > * + * {
  margin-left: 18px;
}

.user-settings svg {
  width: 22px;
  flex-shrink: 0;
}

.button {
  display: flex;
  background-color: transparent;
  align-items: center;
  border: 2px solid var(--border-color);
  border-radius: 25px;
  color: var(--body-color);
  padding: 8px 16px;
  font-family: var(--body-font);
  cursor: pointer;
  font-weight: 600;
  font-size: 14px;
}
.button svg {
  margin-right: 8px;
  width: 20px;
  fill: var(--body-color);
}

.search-bar {
  height: 90px;
  position: relative;
}
.search-bar input {
  height: 100%;
  width: 100%;
  display: block;
  background-color: transparent;
  border: none;
  padding: 0 10px 0 54px;
  background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg width='18' height='18' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'%3e%3cdefs%3e%3cpath d='M18.5 17h-.79l-.28-.27a6.5 6.5 0 10-.7.7l.27.28v.79l5 4.99L23.49 22l-4.99-5zm-6 0a4.5 4.5 0 11-.01-8.99A4.5 4.5 0 0112.5 17z' id='a'/%3e%3c/defs%3e%3cg transform='translate(-6 -6)' fill='none' fill-rule='evenodd'%3e%3cmask id='b' fill='%23fff'%3e%3cuse xlink:href='%23a'/%3e%3c/mask%3e%3cg mask='url(%23b)' fill='%23D8D8D8'%3e%3cpath d='M3 3h24v24H3z'/%3e%3c/g%3e%3c/g%3e%3c/svg%3e");
  background-repeat: no-repeat;
  background-size: 16px;
  background-position: 25px 50%;
  color: #7c7c7c;
}
.search-bar input::-moz-placeholder {
  color: var(--body-color);
}
.search-bar input:-ms-input-placeholder {
  color: var(--body-color);
}
.search-bar input::placeholder {
  color: var(--body-color);
}

.user-profile {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  -o-object-fit: cover;
     object-fit: cover;
}
.user-profile + svg {
  width: 14px;
}

.notify {
  position: relative;
}
.notify:before {
  content: "";
  position: absolute;
  background-color: var(--logo-color);
  width: 5px;
  height: 5px;
  border-radius: 50%;
  right: -6px;
  bottom: 15px;
}

.menu-item.active {
  color: var(--logo-color);
}

.wrapper {
  width: 100%;
  display: flex;
  flex-grow: 1;
  overflow: auto;
  background-color: var(--theme-bg-color);
}

.side-wrapper:not(:last-child) {
  border-bottom: 1px solid var(--border-color);
}

.side-wrapper svg {
  width: 20px;
  fill: var(--body-color);
  margin-right: 25px;
  flex-shrink: 0;
}

.username {
  color: var(--main-color);
  font-size: 15px;
}

.side-menu a {
  text-decoration: none;
  font-weight: 500;
  color: var(--main-color);
  display: flex;
  align-items: center;
  font-size: 15px;
  white-space: nowrap;
}
.side-menu a:not(:last-child) {
  margin-bottom: 20px;
}

.side-menu {
  padding: 20px;
}

.side-title {
  padding: 0 0 20px;
  font-size: 15px;
}

.user {
  display: flex;
  align-items: center;
}

.user + .user {
  margin-top: 15px;
}

.user-img {
  border-radius: 50%;
  width: 30px;
  height: 30px;
  margin-right: 16px;
  -o-object-fit: cover;
     object-fit: cover;
  -o-object-position: center;
     object-position: center;
}

.show-more {
  margin-top: 20px;
  padding: 12px 16px;
}

.left-side {
  width: 270px;
  display: flex;
  flex-direction: column;
  border-right: 1px solid var(--border-color);
  overflow: auto;
  flex-shrink: 0;
}

.main-container {
  padding: 25px;
  flex-grow: 1;
  overflow: auto;
}

.menu-items {
  display: flex;
  cursor: pointer;
}

.profile-menu-link {
  padding: 20px;
  transition: 0.2s;
}
.profile-menu-link.active, .profile-menu-link:hover {
  border-bottom: 3px solid var(--logo-color);
  color: var(--logo-color);
}

.profile-info {
  justify-content: center;
  display: flex;
  background-color: rgba(0, 0, 0, 0.3);
  width: 100%;
  z-index: 2;
}

.profile-name {
  color: var(--main-color);
}

.profile-item {
  display: flex;
  align-items: center;
  color: #fff;
  padding: 26px 16px;
  white-space: nowrap;
}
.profile-item svg {
  width: 22px;
  margin-right: 10px;
}

.profile-contact-info {
  position: absolute;
  display: flex;
  right: 10px;
  top: 20px;
  color: #fff;
}
.profile-contact-info svg {
  width: 18px;
}

.profile-contact {
  border: 1px solid rgba(239, 239, 239, 0.3);
  padding: 16px;
  margin-left: 10px;
  border-radius: 50%;
  cursor: pointer;
}

.follow-buttons {
  display: flex;
}

.follow {
  border: 2px solid var(--border-color);
  border-radius: 25px 0 0 25px;
  color: var(--body-color);
  padding: 8px 16px;
  font-weight: 600;
  font-size: 14px;
  cursor: pointer;
  background-color: transparent;
}
.follow:hover {
  background-color: var(--header-bg-color);
}

.follow-option {
  border-radius: 0 25px 25px 0;
  margin-left: -2px;
}

.trends {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 40px 45px;
}
.trends a {
  text-decoration: none;
  color: var(--body-color);
  display: flex;
  align-items: center;
  font-size: 15px;
  white-space: nowrap;
}

.trends svg {
  width: 20px;
  margin-right: 16px;
}

.follow-option.active {
  background-color: var(--header-bg-color);
  margin-left: -3px;
}

.play-all {
  background-color: var(--logo-color);
  color: #fff;
  padding: 10px 20px;
  border-radius: 30px;
  display: flex;
  align-items: center;
}
.play-all svg {
  width: 12px;
  flex-shrink: 0;
  margin-right: 8px;
}

.videos {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  grid-column-gap: 20px;
  grid-row-gap: 20px;
}

.video video {
  transition: 0.4s;
  max-width: 100%;
  display: block;
  border-radius: 4px 4px 0 0;
}

.video {
  overflow: hidden;
  box-shadow: -1px 3px 8px -1px rgba(0, 0, 0, 0.1);
  border-radius: 4px;
  position: relative;
  background-color: var(--header-bg-color);
  cursor: pointer;
}
.video:hover .video-time {
  opacity: 0;
}
.video:hover video {
  transform: scale(2.2);
  transform-origin: center;
}
.video:hover .view {
  padding: 10px;
}

.video-time {
  position: absolute;
  background-color: rgba(0, 0, 0, 0.5);
  padding: 8px;
  border-radius: 15px;
  font-size: 12px;
  color: #fff;
  bottom: 80px;
  right: 6px;
  transition: 0.3s ease-in;
}

.video-content {
  width: 100%;
  color: var(--main-color);
  padding: 15px 10px 0;
  border-radius: 0 0 4px 4px;
  font-size: 14px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.view {
  padding: 10px;
  position: relative;
  background-color: #fff;
  z-index: 1;
  font-size: 13px;
}

.load-more {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 30px;
  border-bottom: 1px solid var(--border-color);
  cursor: pointer;
}
.load-more svg {
  width: 16px;
  margin-right: 15px;
}
.load-more:hover svg {
  -webkit-animation: load 0.9s linear infinite;
          animation: load 0.9s linear infinite;
}



@keyframes load {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
.language {
  margin-bottom: 8px;
}

.footer-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.footer-links a {
  text-decoration: none;
  color: var(--main-color);
}
.footer-links a + a {
  margin-left: 8px;
}

.footer-links {
  display: flex;
}

.link-footer a {
  color: var(--body-color);
  font-size: 14px;
}

.footer {
  padding: 30px 0;
}
.footer-last {
  border-top: 1px solid var(--border-color);
  padding: 30px 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.social-media {
  display: flex;
  align-items: center;
}
.social-media svg {
  width: 100%;
}
.social-media a {
  border: 1px solid var(--border-color);
  border-radius: 50%;
  color: var(--body-color);
  padding: 8px;
  flex-shrink: 0;
  width: 36px;
  height: 36px;
  margin-right: 12px;
}

.policy a {
  text-decoration: none;
  color: var(--body-color);
}

@media (max-width: 1030px) {
  .profile-name {
    display: none;
  }

  .profile-menu-link {
    padding: 20px 10px;
    font-size: 14px;
  }

  .trends {
    padding: 40px 10px;
  }
}
@media (max-width: 1120px) {
  .footer-row {
    flex-direction: column;
  }
  .footer-row + .footer-row {
    margin-top: 10px;
  }
  .footer-row .button {
    display: none;
  }
}
@media (max-width: 900px) {
  .play-all {
    color: transparent;
    white-space: nowrap;
    width: 30px;
    padding: 0;
    fill: #fff;
    height: 30px;
    position: relative;
  }

  .profile-item {
    padding: 20px 10px;
  }

  .play-all svg {
    position: absolute;
    left: 58%;
    top: 50%;
    transform: translate(-50%, -50%);
    fill: #fff;
  }
}
@media (max-width: 840px) {
  .profile-contact {
    padding: 6px;
  }

  .profile-item, .profile-avatar {
    flex-direction: column;
  }

  .profile-item svg {
    margin-right: 0;
  }

  .profile-item {
    text-align: center;
  }

  .profile-img {
    margin-right: 0;
    margin-top: 10px;
  }

  .profile-name {
    display: block;
    margin-bottom: 10px;
    margin-top: 6px;
  }

  .profile-menu {
    flex-direction: column;
  }

  .menu-items {
    order: 1;
  }
}
@media (max-width: 980px) {
  .videos {
    grid-template-columns: 1fr 1fr;
  }

  .profile {
    min-height: 380px;
    max-height: 380px;
  }
}
@media (max-width: 800px) {
  .trends .follow-buttons {
    display: none;
  }
}
@media (max-width: 750px) {
  .left-side {
    display: none;
  }

  .header-menu {
    display: none;
  }

  .search-bar input  {
    max-width: 140px;
  }

  .user-settings button {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    padding: 0;
    position: relative;
    color: transparent;
  }

  .user-settings button svg {
    margin-right: 0;
    position: absolute;
    display: block;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
  }
}
@media (max-width: 440px) {
  .user-settings svg {
    display: none;
  }

  .videos {
    grid-template-columns: 1fr;
  }
}
.dark-light {
  position: fixed;
  bottom: 30px;
  right: 30px;
  background-color:#fff;
  box-shadow: -1px 3px 8px -1px rgba(0, 0, 0, 0.2);
  padding: 8px;
  border-radius: 50%;
  z-index: 3;
}
.dark-light svg {
  width: 28px;
}

.dark-mode .dark-light svg {
  fill: #ffce45;
  stroke: #ffce45;
}

.dark-light svg {
  fill: transparent;
  transition: 0.5s;
}

@media (max-width: 475px) {
  .footer-links {
    flex-direction: column;
  }

  .footer-links a + a {
    margin-left: 0;
  }

  .footer-row:last-child {
    align-items: flex-end;
  }

  .footer-row {
    align-items: flex-start;
  }

  .footer {
    display: flex;
    justify-content: space-between;
  }

  .footer-links a {
    margin-bottom: 5px;
  }

  .policy {
    display: none;
  }

  .dark-light {
    bottom: 60px;
  }
}
.offscreen-nav {
  position:absolute;
  overflow: hidden;
  -webkit-transform: translate3d(-20rem,0,0);
  transform: translate3d(-20rem,0,0);
  -webkit-transition: -webkit-all 600ms ease;
  transition: all 600ms ease;
  z-index:777;
}

.mainBody {
  position:relative;
  height:100%;
  display: flex;
  overflow: hidden;
}
.toggle-nav {
  -webkit-transform: translate3d(0,0,0);
  transform: translate3d(0,0,0);
}
.profieo{
    margin-top:90px;
    height:555px;
    width:100%;
    
}
.banner{
    height:300px;
    width:1300px;
    position:absolute;
    margin-left:10px;
    margin-top:20px;
    background:url("https://wallpaperaccess.com/full/4561412.jpg");
    border-radius:20px;
    background-size:cover;
}
.profieo-inform{
    height:220px;
    width:100%;
    margin-top:330px;
    position:absolute;
    background-color:#fff;
}
.profieo-logo{
    height:150px;
    width:150px;
    border-radius:50%;
    border:1px solid black;
    position:absolute;
    margin-left:50px;
    margin-top:20px;
    background:url("https://tse2.mm.bing.net/th/id/OIP.Dt1uED_9vdvfz5snvkIcRwHaHa?rs=1&pid=ImgDetMain&o=7&rm=3");
    background-size:cover;
}

.profieo-name{
    height:200px;
    width:700px;
    line-height:35px;
    position:absolute;
    margin-left:260px;
    margin-top:20px;

}
.profieo-name h1{
    color:black;
    text-transform:uppercase;
}
.profieo-name p{
    color:black;
}
.profieo-name .sels{
   height:40px;
   display:flex;
   border-radius:20px;
   gap:20px;
}
.profieo-name .sub{
    background-color:black;
    color:white;
    width:120px;
    border-radius:15px;
    padding-top:3px;
    padding-left:25px;
}
.profieo-name .pub{
    background-color:#e5e5e5;
    color:black;
    width:120px;
    border-radius:15px;
    padding-top:3px;
    padding-left:30px;
   
}
.pro-menu{
    height:40px;
    width:100%;
    display:flex;
    gap:50px;
    position:sticky;
    top:90px;
    z-index:666;
}
.pro-menu p{
    margin-left:50px;
    color:black;
    background:none;
    padding:5px;
    
}
.reel{
  flex-direction:column;
   justify-content: space-around;
  flex-wrap: wrap;
  display:flex;
  height:600px;
  width:100%;
  padding:20px;
  overflow-x:auto;
  gap:20px;
}
.reel-vid{
  border-radius:20px;
  height:500px;
  width:350px;
  
}
 .reel-vid .rel-vs{
  height:350px;
  width:300px;
  border:1px solid #000;
  margin-left:10px;
  border-radius:20px;
  
}
.reel-vid p{
  width:250px;
 font-size:15px;
 margin-left:20px;
 margin-top:10px;
}
.reel-vid i{
  margin-left:290px;
  margin-top:-30px;
}

.player{
  background-color: #f9f9f9;
  width:100%;
  height: 600px;
  padding: 15px 15px;
  border-top: 1px solid #ddd;
  overflow-y: scroll;
}
.videos__container {
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  flex-wrap: wrap;
}
.video {
  width: 310px;
  margin-bottom: 30px;
}

.video__thumbnail {
  width: 100%;
  height: 170px;
  border-radius:20px;
}

.video__thumbnail img {
  object-fit: cover;
  height: 100%;
  width: 100%;
  border-radius:20px;
}


.author img {
  object-fit: cover;
  border-radius: 50%;
  height: 40px;
  width: 40px;
  margin-right: 10px;
}

.video__details {
  display: flex;
  margin-top: 10px;
}

.title {
  display: flex;
  flex-direction: column;
}

.title h3 {
  color: rgb(3, 3, 3);
  line-height: 18px;
  font-size: 14px;
  margin-bottom: 6px;
}

.title a,
span {
  text-decoration: none;
  color: rgb(96, 96, 96);
  font-size: 14px;
}

h1 {
  font-size: 20px;
  margin-bottom: 10px;
  color: rgb(3, 3, 3);
}

@media (max-width: 425px) {
  .header__search {
    display: none;
  }

  .header__icons .material-icons {
    display: none;
  }

  .header__icons .display-this {
    display: inline;
  }

  .sidebar {
    display: none;
  }
}

@media (max-width: 768px) {
  .header__search {
    display: none;
  }

  .sidebar {
    display: none;
  }

  .show-sidebar {
    display: inline;
    position: fixed;
    top: 4.4rem;
    height: auto;
  }
}

@media (max-width: 941px) {
  .header__search input {
    width: 300px;
  }
}


     </style>
 </head>
 <body>
     <div class="header">
      <div class="header__left" id="cod">
        <i id="menu" class="material-icons acto">menu</i> 
      </div>
      <div class="header__search">
        <form action="">
          <input type="text" placeholder="Search" />
          <button><i class="material-icons">search</i></button>
        </form>
      </div>

      <div class="header__icons">
        <i class="material-icons display-this">search</i>
        <i class="material-icons">videocam</i>
        <i class="material-icons">apps</i>
        <i class="material-icons">notifications</i>
        <i class="material-icons display-this">account_circle</i>
      </div>
    </div>
    <div class="offscreen-nav">
  <div class="mainBody">
    <div class="wrapper">
  <div class="left-side">
   <div class="side-wrapper">
    <div class="side-menu">
     <a href="#">
      <svg width="20" height="17" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
       <defs>
        <path id="a" d="M13 22v-6h4v6h5v-8h3L15 5 5 14h3v8z" />
       </defs>
       <g transform="translate(-5 -5)" fill="none" fill-rule="evenodd">
        <mask id="b" fill="currentColor">
         <use xlink:href="#a" />
        </mask>
        <g mask="url(#b)" fill="currentColor">
         <path d="M2 2h26v26H2z" />
        </g>
       </g>
      </svg>
      Home
     </a>
     <a href="#">
      <svg viewBox="0 0 512 512" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
       <path d="M210.35 246.63c33.88 0 63.22-12.15 87.2-36.13 23.97-23.97 36.12-53.3 36.12-87.19 0-33.87-12.15-63.2-36.13-87.19C273.57 12.15 244.23 0 210.35 0c-33.89 0-63.22 12.15-87.19 36.13s-36.13 53.3-36.13 87.18c0 33.89 12.16 63.23 36.13 87.2 23.98 23.97 53.32 36.12 87.2 36.12zm0 0M426.13 393.7a304.6 304.6 0 00-4.15-32.35 254.9 254.9 0 00-7.96-32.53 160.66 160.66 0 00-13.37-30.33 114.48 114.48 0 00-20.16-26.28c-7.96-7.61-17.7-13.73-28.97-18.2-11.22-4.44-23.66-6.69-36.97-6.69-5.23 0-10.28 2.14-20.05 8.5-6 3.92-13.03 8.45-20.87 13.46-6.71 4.27-15.8 8.28-27.02 11.9a107.28 107.28 0 01-33.04 5.34c-10.97 0-22.09-1.8-33.05-5.34-11.2-3.62-20.3-7.62-27-11.9-7.76-4.96-14.8-9.5-20.9-13.46-9.74-6.36-14.8-8.5-20.03-8.5-13.3 0-25.75 2.25-36.97 6.7-11.26 4.45-21 10.57-28.97 18.2a114.49 114.49 0 00-20.15 26.27c-5.56 9.78-10.06 19.99-13.38 30.34a255.5 255.5 0 00-7.95 32.52 303.52 303.52 0 00-4.15 32.36C.34 403.51 0 413.68 0 423.95c0 26.73 8.5 48.36 25.25 64.32C41.8 504.02 63.69 512 90.32 512h246.53c26.62 0 48.5-7.98 65.06-23.73 16.76-15.95 25.25-37.59 25.25-64.32 0-10.32-.35-20.5-1.03-30.25zm0 0" /></svg>
      My channel
     </a>
     <a href="#">
      <svg viewBox="0 0 512.07 512.07" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
       <path d="M509.76 194.64c-6.15-18.86-22.95-31.04-42.78-31.04H339.06L298.78 41.27c-6.2-18.8-22.95-30.93-42.73-30.93h-.2c-19.85.08-36.6 12.35-42.67 31.26l-39.1 122H45.09c-19.88 0-36.69 12.22-42.81 31.14-6.12 18.92.33 38.68 16.45 50.33L123.1 320.5l-40.17 122c-6.21 18.87.14 38.65 16.18 50.39a44.86 44.86 0 0026.56 8.84c9.17 0 18.35-2.9 26.37-8.7l104.54-75.56 103.3 75.44c16.03 11.7 36.78 11.76 52.87.15s22.58-31.33 16.52-50.23L390.04 320.5l103.48-75.56c16.02-11.7 22.4-31.44 16.24-50.3z" /></svg>
      Popular video
     </a>
     <a href="#">
      <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512">
       <path d="M490.24 113.92c-13.89-24.7-28.96-29.25-59.65-30.98C399.94 80.86 322.85 80 256.06 80c-66.9 0-144.03.86-174.65 2.91-30.63 1.76-45.73 6.27-59.75 31.01C7.36 138.59 0 181.09 0 255.9v.26c0 74.5 7.36 117.31 21.66 141.73 14.02 24.7 29.1 29.18 59.72 31.26 30.65 1.8 107.77 2.85 174.68 2.85 66.79 0 143.88-1.06 174.56-2.82 30.7-2.08 45.76-6.56 59.65-31.26C504.7 373.5 512 330.69 512 256.19v-.16-.1c0-74.84-7.3-117.34-21.76-142.01zM192 352V160l160 96-160 96z" /></svg>
      Subscriptions
     </a>
     <a href="#">
      <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 448 448">
       <path d="M234.67 138.67v106.66l91.3 54.19 15.36-25.92-74.66-44.27v-90.66z" />
       <path d="M255.9 32C149.75 32 64 117.97 64 224H0l83.1 83.1 1.49 3.09L170.67 224h-64c0-82.45 66.88-149.33 149.33-149.33S405.33 141.55 405.33 224 338.45 373.33 256 373.33c-41.28 0-78.5-16.85-105.5-43.84l-30.18 30.19A190.78 190.78 0 00255.89 416C362.03 416 448 330.03 448 224S362.03 32 255.9 32z" />
      </svg>
      History views
     </a>
     <a href="#">
      <svg viewBox="0 0 443.29 443.29" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
       <path d="M221.65 0C99.43 0 0 99.43 0 221.65s99.43 221.64 221.65 221.64 221.64-99.43 221.64-221.64S343.86 0 221.65 0zm0 415.59c-106.94 0-193.94-87-193.94-193.94S114.7 27.7 221.65 27.7s193.94 87 193.94 193.94-87 193.94-193.94 193.94z" />
       <path d="M235.5 83.12h-27.7v144.26l87.17 87.18 19.59-19.59-79.06-79.06z" /></svg>
      Watch Later
     </a>
     <a href="#">
      <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512">
       <path d="M53.33 224A53.4 53.4 0 000 277.33V448a53.4 53.4 0 0053.33 53.33h64a52.95 52.95 0 0032-10.8V224h-96zM512 304a47.3 47.3 0 00-13.89-33.58 52.97 52.97 0 0013.66-40.72c-2.5-27.12-26.93-48.37-55.64-48.37H324.35c6.53-19.82 16.98-56.15 16.98-85.33 0-46.27-39.31-85.33-64-85.33-22.16 0-38 12.48-38.67 12.99a10.72 10.72 0 00-4 8.34v72.34l-61.43 133.1-2.56 1.3V467.4C188.03 475.6 210 480 224 480h195.82c23.23 0 43.56-15.66 48.34-37.27a47.99 47.99 0 00-3.86-32.04 47.78 47.78 0 0021.35-64.02A47.76 47.76 0 00512 304z" /></svg>
      Liked Videos
     </a>
     <a href="#">
      <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 320 320">
       <path d="M0 96h256v42.67H0zM0 10.67h256v42.67H0zM0 181.33h170.67V224H0zM213.33 181.33v128l106.67-64z" /></svg>
      Playlists
     </a>
    </div>
   </div>
   <div class="side-wrapper">
    <div class="side-menu">
     <div class="side-title">Subscriptions</div>
     <div class="user">
      <img src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1400&q=80" alt="" class="user-img">
      <div class="username">Inez Gibson</div>
     </div>
     <div class="user">
      <img src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=200&fit=max&s=046c29138c1335ef8edee7daf521ba50" alt="" class="user-img">
      <div class="username">Francis Wolfe</div>
     </div>
     <div class="user">
      <img src="https://randomuser.me/api/portraits/women/63.jpg" alt="" class="user-img">
      <div class="username">Inez Gibson</div>
     </div>
     <div class="user">
      <img src="https://pbs.twimg.com/profile_images/737221709267374081/sdwta9Oh.jpg" alt="" class="user-img">
      <div class="username">Anne Norton</div>
     </div>
     <div class="user">
      <img src="https://pbs.twimg.com/profile_images/2452384114/noplz47r59v1uxvyg8ku.png" alt="" class="user-img">
      <div class="username">Bessie Casey</div>
     </div>
     <div class="user">
      <img src="https://images.unsplash.com/photo-1575084713138-342cae5f8d00?ixlib=rb-1.2.1&auto=format&fit=crop&w=958&q=80" alt="" class="user-img">
      <div class="username">Hanry Davidson</div>
     </div>
     <button class="button show-more">Show More
     </button>
    </div>

   </div>
   <div class="side-wrapper">
    <div class="side-menu">
     <div class="side-title">Popular Channels</div>
     <a href="#">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 415.96 415.96">
       <path d="M328.71 264.54c12.93-21.63 21.5-49 23.17-76.07 1.06-17.37-2.82-35.61-11.2-52.76-13.15-26.95-35.74-42.08-57.57-56.7-16.29-10.92-31.68-21.22-42.56-35.94l-1.95-2.63c-6.43-8.64-13.7-18.43-14.85-26.65C222.6 5.47 215.05-.45 206.8.03a15.96 15.96 0 00-14.88 15.93v285.12c-13.4-8.13-29.92-13.12-48-13.12-44.1 0-80 28.7-80 64s35.9 64 80 64 80-28.7 80-64v-186.5c24.03 9.2 63.36 32.58 74.18 87.2-2.02 2.98-3.94 6.18-6.18 8.74a15.94 15.94 0 001.44 22.56 15.94 15.94 0 0022.56-1.44c4.29-4.86 8.1-10.56 11.75-16.5.38-.46.73-.94 1.05-1.48z" /></svg>
      Music Channels
     </a>
     <a href="#">
      <svg viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg">
       <g fill="currentColor" fill-rule="nonzero">
        <path d="M15.68 23.94a1 1 0 001.27-.62A3.44 3.44 0 0120 21a1 1 0 000-2c-3.68 0-4.9 3.53-4.95 3.68a1 1 0 00.63 1.26zM40 21c1.4.08 2.6 1 3.05 2.32a1 1 0 001.9-.64C44.9 22.53 43.68 19 40 19a1 1 0 000 2z" />
        <path d="M1.27 51.44A6.27 6.27 0 006.17 54a5.15 5.15 0 003.79-1.65 30.07 30.07 0 0040.02.06 5.15 5.15 0 004.69 1.66 6.39 6.39 0 005.27-7.09 5.25 5.25 0 00-3.1-4.09A26.12 26.12 0 0059 32.5c0-11.66-7.7-21.97-19.23-25.87-.1-.43-.23-.86-.4-1.27a8.65 8.65 0 00-3.48-3.85A11.42 11.42 0 0022.7 2.79a8.42 8.42 0 00-2.37 3.8C8.74 10.48 1 20.81 1 32.5c0 3.53.72 7.03 2.1 10.28-.35.15-.68.35-1 .58a5.77 5.77 0 00-.83 8.08zM56.7 45.1c.7.53 1.15 1.31 1.26 2.18a4.4 4.4 0 01-3.6 4.82 3.24 3.24 0 01-2.95-1.07 27.6 27.6 0 004.57-6.32c.26.1.5.23.72.4zM19.98 8.83a11.42 11.42 0 003.2 7.8 17.3 17.3 0 003.96 3.18A9.24 9.24 0 0030.75 21a1 1 0 00.13-2 7.32 7.32 0 01-2.72-.91 15.33 15.33 0 01-3.96-3.34c-2.37-2.9-3.42-7.42-.14-10.5a9.47 9.47 0 0110.79-1.03c1.17.68 2.1 1.7 2.68 2.94a4.15 4.15 0 01-1.07 5.1c-2.2 1.72-6.27 1.67-8.72-.1-1.25-.9-2.36-2.36-1.74-3.75.78-1.76 3.89-2.26 6.04-1.52.5.12.91.46 1.12.93a1 1 0 001.95-.45 3.5 3.5 0 00-2.42-2.38c-3.08-1.05-7.24-.26-8.52 2.6-.9 2.05.03 4.48 2.4 6.19 3.21 2.32 8.2 2.35 11.12.06a5.82 5.82 0 002.22-4.03C50.18 12.62 57 21.97 57 32.5 57 46.56 44.89 58 30 58S3 46.56 3 32.5C3 22 9.77 12.68 19.98 8.84zM3.3 44.97c.2-.15.43-.27.66-.37a27.62 27.62 0 004.57 6.37 3.25 3.25 0 01-2.9 1c-1.1-.18-2.1-.8-2.75-1.7a3.77 3.77 0 01.42-5.3z" />
        <path d="M26.97 32.98a1 1 0 001.03-.95c.01-.17.16-1.03 2-1.03s1.99.86 2 1a1 1 0 002 0c0-1.04-.84-3-4-3s-4 1.96-4 3c0 .54.43.97.97.98zM17.2 27.4a.98.98 0 00.18 1.36c.43.33 1.04.28 1.4-.13A3 3 0 0121 28c.78-.09 1.57.13 2.2.6a1 1 0 101.6-1.2c-.1-.14-1.13-1.4-3.8-1.4s-3.7 1.26-3.8 1.4zM36.77 28.63A3 3 0 0139 28c.78-.09 1.57.13 2.2.6a1 1 0 001.6-1.2c-.1-.14-1.13-1.4-3.8-1.4s-3.7 1.26-3.8 1.4a.98.98 0 00.18 1.36c.43.33 1.04.28 1.4-.13zM29.93 56a23.42 23.42 0 0015.75-6c3.39-3.26 4.82-9.4 1.22-13.62a6.52 6.52 0 00-6.44-2.1c-1.02.27-2.02.63-2.98 1.08-.73.34-1.48.63-2.24.87-1.72.5-3.5.75-5.3.77-1.8-.02-3.59-.28-5.32-.77a18.4 18.4 0 01-2.24-.87c-.95-.45-1.95-.81-2.98-1.08a6.53 6.53 0 00-6.43 2.1c-3.6 4.23-2.18 10.36 1.21 13.62a23.42 23.42 0 0015.75 6zm0-2a21.96 21.96 0 01-5.4-.71 6.7 6.7 0 015.4-2.29 6.7 6.7 0 015.4 2.29c-1.77.46-3.58.7-5.4.71zm2-15.12V40a1 1 0 01-1 1h-2a1 1 0 01-1-1v-1.12c.67.07 1.34.12 2 .12s1.34-.05 2-.12zm-17.45-1.2a4.48 4.48 0 014.47-1.45c.9.24 1.79.56 2.63.97.8.37 1.64.69 2.49.95.61.18 1.23.32 1.86.44V40a3 3 0 003 3h2a3 3 0 003-3v-1.41c.62-.13 1.25-.26 1.86-.44.85-.26 1.68-.58 2.49-.95.84-.4 1.72-.73 2.63-.97a4.53 4.53 0 014.47 1.45c2.84 3.34 1.65 8.25-1.09 10.88a19.46 19.46 0 01-6.97 4.12C36.1 50.48 33.24 49 29.93 49s-6.18 1.47-7.39 3.68a19.46 19.46 0 01-6.97-4.12c-2.74-2.63-3.93-7.54-1.09-10.88z" />
       </g>
      </svg>
      Baby Channel
     </a>
     <a href="#">
      <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
       <path d="M17.23 18.63H6.69a.75.75 0 01-.75-.76 14.3 14.3 0 012.88-8.44l-2.95.25a1.72 1.72 0 01-1.85-1.7V7.1c0-1.19.8-2.24 1.94-2.57l5.02-1.6V.76a.75.75 0 011.2-.6l2.23 1.67a7.8 7.8 0 012.94 9.73 5.76 5.76 0 00.12 5.13l.43.86a.75.75 0 01-.67 1.1z" fill="#eceff1" />
       <path d="M19.25 21.5H4.75a.75.75 0 01-.75-.75V19.5c0-.94.75-2 1.75-2h12.5c1 0 1.75 1.06 1.75 2v1.25c0 .41-.34.75-.75.75z" fill="#cfd8dc" />
       <path d="M21.25 24H2.75a.75.75 0 01-.75-.75v-1.5c0-.96.79-1.75 1.75-1.75h16.5c.96 0 1.75.79 1.75 1.75v1.5c0 .41-.34.75-.75.75z" fill="#eceff1" />
       <path d="M17.23 18.63a.75.75 0 01-.67-.41l-.43-.86a7.3 7.3 0 01-.15-6.41 6.32 6.32 0 00-2.42-7.9l-1.08-.8V3.5c0 .32-.21.61-.52.71L6.39 5.98c-.52.15-.87.61-.87 1.13v.87c0 .07.04.12.07.15a.2.2 0 00.16.05l4.7-.4c.32-.01.6.15.74.42s.1.6-.1.83l-.3.33a13.02 13.02 0 00-3.35 8.53c-.01.42-.34.78-.77.74a.75.75 0 01-.73-.76 14.3 14.3 0 012.88-8.44l-2.95.25a1.71 1.71 0 01-1.85-1.7V7.1c0-1.19.8-2.24 1.94-2.57l5.02-1.6V.76a.75.75 0 011.2-.6l2.23 1.67a7.8 7.8 0 012.94 9.73 5.76 5.76 0 00.12 5.13l.43.86a.75.75 0 01-.67 1.1z" />
       <path d="M13.51 19a.77.77 0 01-.35-.08c-.14-.07-1.41-.78-1.41-3.42 0-1.48.5-2.45 1-3.39.51-1 1-1.94 1-3.61a.75.75 0 011.5 0c0 2.04-.62 3.24-1.18 4.3-.44.85-.82 1.6-.82 2.7 0 1.67.61 2.1.62 2.1.37.18.5.62.32 1-.13.25-.4.4-.68.4zM21.25 24H2.75a.75.75 0 01-.75-.75v-1.5c0-.96.79-1.75 1.75-1.75h16.5c.96 0 1.75.79 1.75 1.75v1.5c0 .41-.34.75-.75.75zM3.5 22.5h17v-.75a.25.25 0 00-.25-.25H3.75a.25.25 0 00-.25.25z" />
       <path d="M19.25 21.5H4.75a.75.75 0 01-.75-.75V19.5c0-.94.75-2 1.75-2h12.5c1 0 1.75 1.06 1.75 2v1.25c0 .41-.34.75-.75.75zM5.5 20h13v-.5c0-.2-.17-.47-.27-.5H5.75c-.08.03-.25.3-.25.5z" /></svg>
      Games Channel
     </a>
     <a href="#">
      <svg viewBox="0 0 509.52 509.52" xmlns="http://www.w3.org/2000/svg">
       <path d="M155.95 301.92l145.69-145.7 51.6 51.6-145.7 145.7zM28.85 297.86l40.3-40.3 182.73 182.72-40.3 40.3zM-.04 387.75l38.18-38.18 121.71 121.72-38.18 38.18zM257.3 69.46l40.3-40.3 182.73 182.73-40.3 40.3zM349.33 38.46L387.73.05l121.72 121.72-38.4 38.4z" /></svg>
      Fitness Channel
     </a>
     <a href="#">
      <svg viewBox="0 0 509.52 509.52" xmlns="http://www.w3.org/2000/svg">
       <path d="M493.8 309.4A62.23 62.23 0 00439 292.2l-13.21 2.33-3.8-12.87C400.5 208.61 332.23 157.6 256 157.6S111.52 208.61 90 281.65l-3.79 12.87-13.2-2.33a62.22 62.22 0 00-54.82 17.22C6.46 321.14 0 336.74 0 353.33s6.46 32.19 18.2 43.92 27.32 18.2 43.92 18.2c16.59 0 32.19-6.46 43.92-18.2a62.64 62.64 0 008.12-10l12.55-19.2 12.56 19.2a62.69 62.69 0 008.12 10 61.71 61.71 0 0043.92 18.2c16.6 0 32.19-6.46 43.92-18.2a62.64 62.64 0 008.12-10l12.56-19.2 12.55 19.2a62.71 62.71 0 008.12 10c11.73 11.73 27.33 18.2 43.92 18.2s32.2-6.47 43.93-18.2a62.62 62.62 0 008.19-10.11l12.57-19.34 12.58 19.34a62.6 62.6 0 008.19 10.11c11.73 11.73 27.33 18.2 43.92 18.2s32.2-6.47 43.93-18.2S512 369.92 512 353.33s-6.46-32.2-18.2-43.93zm-276.1.6h-30v-28.67h30zm53.3-48.45h-30V232.9h30zM324.3 310h-30v-28.67h30zM385.2 418.9c-35.78 35.3-93.48 35.33-129.3.1-35.77 35.2-93.4 35.2-129.19 0-25.22 24.82-61.3 32.11-92.94 21.94l10.31 35.14A50.27 50.27 0 0092.06 512h327.88a50.27 50.27 0 0047.98-35.92L478.2 441a92.3 92.3 0 01-28.33 4.45 91.5 91.5 0 01-64.69-26.54zM143.52 131.66h30c0-7.86 2.68-11.1 7.56-16.96 6.1-7.36 14.47-17.44 14.47-36.12 0-18.69-8.37-28.77-14.47-36.12-4.88-5.88-7.56-9.1-7.56-16.97h-30c0 18.69 8.36 28.77 14.47 36.12 4.87 5.87 7.56 9.1 7.56 16.97 0 7.85-2.69 11.09-7.56 16.96-6.1 7.36-14.47 17.43-14.47 36.12zM229.99 106.17h30c0-7.86 2.68-11.1 7.55-16.97 6.11-7.35 14.47-17.43 14.47-36.12 0-18.68-8.36-28.76-14.47-36.12C262.67 11.1 260 7.86 260 0h-30c0 18.68 8.36 28.76 14.47 36.12 4.87 5.87 7.55 9.1 7.55 16.96 0 7.86-2.68 11.1-7.55 16.96-6.1 7.36-14.47 17.44-14.47 36.13zM316.45 131.66h30c0-7.86 2.69-11.1 7.56-16.96 6.1-7.36 14.47-17.44 14.47-36.12 0-18.69-8.36-28.77-14.47-36.12-4.87-5.88-7.56-9.1-7.56-16.97h-30c0 18.69 8.37 28.77 14.47 36.12 4.88 5.87 7.56 9.1 7.56 16.97 0 7.85-2.68 11.09-7.56 16.96-6.1 7.36-14.47 17.43-14.47 36.12z" /></svg>
      Food Channels
     </a>
     <a href="#">
      <svg viewBox="0 0 496 496" xmlns="http://www.w3.org/2000/svg">
       <path d="M132 193C59.22 193 0 252.23 0 325s59.22 132 132 132 132-59.2 132-132-59.22-132-132-132zm-4.55 113.51l19.54 6.74c37.85 13.06 39.07 66.83 1.01 81.07 0 10.22-7.64 16.69-16 16.69-8.28 0-16-6.37-16-16.69a43.14 43.14 0 01-28.02-40.35 16 16 0 1132 0c0 6.1 4.97 11.07 11.07 11.07h1.9c12.49 0 15.33-17.5 3.6-21.54l-19.54-6.73C79.16 323.7 77.94 269.94 116 255.7c0-10.23 7.64-16.7 16-16.7 8.28 0 16 6.38 16 16.7a43.14 43.14 0 0128.02 40.35 16 16 0 11-32 0c0-6.1-4.97-11.07-11.07-11.07h-1.9c-12.49 0-15.33 17.5-3.6 21.53zM496 441.01a16 16 0 01-16 16H256a16 16 0 110-32h68V225a16 16 0 1132 0v200h81V161a16 16 0 1132 0v264h11a16 16 0 0116 16zM223.69 188.7l68.5-68.5a16 16 0 0122.62 0L340 145.38l74.37-74.37H407a16 16 0 110-32c49.58 0 46.92-.13 49.12.3A16.04 16.04 0 01469 55.02v46a16 16 0 11-32 0v-7.37l-85.69 85.68a16 16 0 01-22.62 0l-25.19-25.18-57.19 57.18a15.95 15.95 0 01-11.31 4.69c-14.12 0-21.42-17.2-11.31-27.31z" /></svg>
      Economy Channels
     </a>
     <a href="#">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 444.27 444.27">
       <path d="M380.15 230.22a64.08 64.08 0 00-52.7 27.67l-16.7-7.15v-10.46l52.28-21.7 13.42-30.93h6.17l30.93 36.72a6.02 6.02 0 109.23-7.77l-24.38-28.95h3.88a6.03 6.03 0 100-12.07h-9.07l7.9-3.74a7.54 7.54 0 003.6-10l-4.54-9.8a7.54 7.54 0 00-6.77-4.37l-83.7-.75h-.08c-2.09 0-4.09.87-5.52 2.4-.15.16-17.25 17.87-48.8 21.98a70.95 70.95 0 00-10.45-14.59c-12.13-13-28.07-19.89-46.1-19.89-3.65 0-7.44.28-11.27.84l-.06.01c-.89.14-21.94 3.41-51.1 11.59-.31.01-.77.03-1.33.03-3.35 0-11.47-.6-14.63-6.12-.23-.4-.45-.86-.65-1.38l13.94-2.53a7.17 7.17 0 00-2.56-14.1l-11.23 2.04c1.72-7.1 5.62-16.8 13.38-30.02a7.54 7.54 0 00-9.17-10.88c-.84.32-20.69 7.95-38.7 26.77a102.14 102.14 0 00-27.6 56.06c1.03-1.99 2.3-3.92 3.9-5.73 0 0 20.58 13.44 8.96 32.9H57c.32 3.95.83 8.03 1.56 12.24a7.55 7.55 0 002.33 4.27l16.84 15.48c-55.38-7.43-75.3 28.52-75.3 28.52-4.16 5.53-2.07 11.49 4.64 8.32A63.7 63.7 0 000 294.33a64.19 64.19 0 0064.11 64.12 64.19 64.19 0 0063.63-71.86h78.34l-30.92-23.06s-36.7 3.55-62.88-24.94c2.74-.14 5.73-.23 8.9-.23 21.23 0 50.79 3.82 71.01 22.02.27.24.54.46.83.65l69.4 46.77a7.52 7.52 0 009.55-.92l27.95-27.96 16.67 7.14a64.18 64.18 0 00-.55 8.27 64.19 64.19 0 0064.11 64.12c35.36 0 64.12-28.76 64.12-64.12s-28.76-64.11-64.12-64.11zm-69.39-15.55l47.24-22.4-6.38 14.72-40.86 16.96v-9.28zM64.11 328.27c-18.71 0-33.94-15.22-33.94-33.94a33.98 33.98 0 0136.29-33.85l-14.04 28.95 27.14 13.17 12.99-26.77a33.73 33.73 0 015.5 18.5 33.98 33.98 0 01-33.94 33.95zm316.04 0a33.99 33.99 0 01-33.63-29.4l25.68 11 11.88-27.73-27.8-11.9a33.83 33.83 0 0123.87-9.85c18.72 0 33.94 15.23 33.94 33.94s-15.22 33.95-33.94 33.95z" /></svg>
      Motorcycle Channels
     </a>
     <a href="#">
      <svg viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
       <path d="M256 0C114.84 0 0 114.84 0 256s114.84 256 256 256 256-114.84 256-256S397.16 0 256 0zm0 482C131.38 482 30 380.62 30 256S131.38 30 256 30s226 101.38 226 226-101.38 226-226 226zm0 0" />
       <path d="M330.88 186.27a52.8 52.8 0 0137.59-15.57c14.2 0 27.54 5.53 37.6 15.57a15 15 0 1021.2-21.22 82.63 82.63 0 00-58.8-24.35 82.63 82.63 0 00-58.8 24.35h-.01a15 15 0 1021.22 21.22zm0 0M105.95 186.27a52.82 52.82 0 0137.58-15.57c14.2 0 27.55 5.53 37.6 15.57a15 15 0 1021.2-21.22 82.63 82.63 0 00-58.8-24.35 82.63 82.63 0 00-58.8 24.35 15 15 0 1021.22 21.22zm0 0M416.67 243H95.33a15 15 0 00-15 15c0 97.02 78.65 175.67 175.67 175.67S431.67 355.02 431.67 258a15 15 0 00-15-15zM256 403.67c-75.95 0-137.5-57.77-144.91-130.67h289.82C393.5 345.9 331.96 403.67 256 403.67zm0 0" /></svg>
      Humor Channels
     </a>
     <button class="button show-more">Show More
     </button>
    </div>
   </div>
  </div>
  </div>
</div>
</div>
<div class="profieo">
    <div class="banner">
    </div>
    <div class="profieo-inform">
      <div class="profieo-logo">
      </div>
      <div class="profieo-name">
        <h1>MR.Pratiraj w <i class="fa fa-check-circle" aria-hidden="true"></i></h1>
        <p><b>@MR6-TECH</b> •15.3 लाख सदस्‍य •1.3 ह व्हिडिओ</p>
        <p>Short, Simple, To the point and Entertaining. ...आणखी</p>
        <p><a href="https://youtube.com/@khanduwaghmare-r2h6e?si=MWTQEEQSL_GNlkI4">https://youtube.com/@khanduwaghmare-r2h6e?si=MWTQEEQSL_GNlkI4</a>आणि आणखी 2 लिंक</p>
         <div class="sels"> 
            <p class="sub">Subscribe</p>
            <p class="pub">PUBLIC</p>
         </div>
     </div>
 </div>
</div>
  <div class="pro-menu">
    <p>Home</p>
    <p>menu</p>
    <p>short</p>
    <p>post</p>
    <p>search</p>
    <p>playlist</p>
    <p>video</p>
  </div>
<section class="reel">
  <div class="reel-vid">
    <div class="rel-vs">
    </div>
    <p>Simple Console.log | JavaScript  #coding</p>
    <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
    <p>10 ह व्ह्यू</p>
   </div>
   <div class="reel-vid">
     <div class="rel-vs">
    </div>
    <p>Simple Console.log | JavaScript  #coding</p>
    <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
     <p>10 ह व्ह्यू</p>
   </div>
   </div>
   <div class="reel-vid">
     <div class="rel-vs">
    </div>
    <p>Simple Console.log | JavaScript  #coding</p>
    <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
     <p>10 ह व्ह्यू</p>
   </div>
   </div>
   <div class="reel-vid">
     <div class="rel-vs">
    </div>
    <p>Simple Console.log | JavaScript  #coding</p>
    <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
     <p>10 ह व्ह्यू</p>
   </div>
   </div>
   <div class="reel-vid">
     <div class="rel-vs">
    </div>
    <p>Simple Console.log | JavaScript  #coding</p>
    <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
     <p>10 ह व्ह्यू</p>
   </div>
   </div> 
</section>
<section class="player">
  
   <div class="videos__container">
    <div class="video">
            <div class="video__thumbnail">
              <a href="https://youtu.be/a9uP8A94VsQ?si=jSmGWfvKDMfTfhAb"><img src="https://img.youtube.com/vi/PpXUTUXU7Qc/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img src="http://aninex.com/images/srvc/web_de_icon.png" alt="" />
              </div>
              <div class="title">
                <h3>
                  Top 5 Programming Languages to Learn in 2021 | Best Programming Languages to Learn
                </h3>
                <a href="">FutureCoders</a>
                <span>10M Views • 3 Months Ago</span>
              </div>
            </div>
          </div>
          <div class="video">
            <div class="video__thumbnail">
              <a href="https://youtu.be/ShFfRsq-dRc?si=q0EmfPvE2Z9cGslO"><img src="https://img.youtube.com/vi/YpTmcCBBdTE/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img src="http://aninex.com/images/srvc/web_de_icon.png" alt="" />
              </div>
              <div class="title">
                <h3>Build A Password Generator with React JS - Beginners Tutorial</h3>
                <a href="">FutureCoders</a>
                <span>10M Views • 3 Months Ago</span>
              </div>
            </div>
          </div>
          <!-- Single Video Ends -->

          <div class="video">
            <div class="video__thumbnail">
              <a href="https://youtu.be/jGyTLCCUoVw?si=o9Cr6i-Ry6w9eNqO"><img src="https://img.youtube.com/vi/46cXFUzR9XM/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img
                  src="https://yt3.ggpht.com/ytc/AAUvwnh53ZRIGnyzC28QrfuggCINb3cfNbNWo4Uc6qR9=s48-c-k-c0x00ffffff-no-rj"
                  alt=""
                />
              </div>
              <div class="title">
                <h3>Bella Ciao Full Song | La Casa De Papel | Money Heist | Netflix India</h3>
                <a href="">Netflix</a>
                <span>10M Views • 11 Months Ago</span>
              </div>
            </div>
          </div>

          <div class="video">
            <div class="video__thumbnail">
              <a href="https://youtu.be/Ii-luSyE708?si=VuK-6QfFJhlv9zCU"><img src="https://img.youtube.com/vi/d2na6sCyM5Q/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img
                  src="https://yt3.ggpht.com/ytc/AAUvwnhESPVEatju_1yE-03-KLeSrnSLc5yy0RcvhPd5Lg=s48-c-k-c0x00ffffff-no-rj"
                  alt=""
                />
              </div>
              <div class="title">
                <h3>DON'T EVER GIVE UP - Elon Musk (Motivational Video)</h3>
                <a href=""> Chispa Motivation</a>
                <span>10M Views • 1 Month Ago</span>
              </div>
            </div>
          </div>

          <div class="video">
            <div class="video__thumbnail">
              <a href="https://youtube.com/shorts/gRsjktUGFzg?si=Y9divhjnjRGiRHj3"><img src="https://img.youtube.com/vi/2Ji-clqUYnA/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img
                  src="https://yt3.ggpht.com/ytc/AAUvwniaHN7MZyFEiNvdHuKMzIWnDF604Z2--O4GCMq-FA=s48-c-k-c0x00ffffff-no-rj"
                  alt=""
                />
              </div>
              <div class="title">
                <h3>Javascript Fundamentals</h3>
                <a href="">Coding Addict</a>
                <span>179K • 8 Months Ago</span>
              </div>
            </div>
          </div>

          <div class="video">
            <div class="video__thumbnail">
               <a href="https://youtu.be/sCeawwVPzSE?si=sxzRGH4ubbX3XGVP"><img src="https://img.youtube.com/vi/3PHXvlpOkf4/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img
                  src="https://yt3.ggpht.com/ytc/AAUvwnifaQZvAunS0OFb2y_cieoVjLCVjqQW8Exf3BC1gg=s48-c-k-c0x00ffffff-no-rj"
                  alt=""
                />
              </div>
              <div class="title">
                <h3>Build 15 JavaScript Projects - Vanilla JavaScript Course</h3>
                <a href=""> freeCodeCamp.org </a>
                <span>470K Views • 8 Months Ago</span>
              </div>
            </div>
          </div>

          <div class="video">
            <div class="video__thumbnail">
               <a href=""><img src="https://img.youtube.com/vi/CVClHLwv-4I/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img
                  src="https://yt3.ggpht.com/ytc/AAUvwnhIz_0Su6HhW6Ym50QCroJCAnF10X9xnnMDboN2=s48-c-k-c0x00ffffff-no-rj"
                  alt=""
                />
              </div>
              <div class="title">
                <h3>Build Real Time Face Detection With JavaScript</h3>
                <a href=""> Web Dev Simplified </a>
                <span>875K Views • 1 Year Ago</span>
              </div>
            </div>
          </div>
          <div class="video">
            <div class="video__thumbnail">
           <a href="https://youtube.com/shorts/kWJvDUf096w?si=1PppegYSf_vzvthx"><img src="https://img.youtube.com/vi/ulprqHHWlng/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img
                  src="https://yt3.ggpht.com/ytc/AAUvwnifaQZvAunS0OFb2y_cieoVjLCVjqQW8Exf3BC1gg=s48-c-k-c0x00ffffff-no-rj"
                  alt=""
                />
              </div>
              <div class="title">
                <h3>AWS Basics for Beginners - Full Course</h3>
                <a href=""> freeCodeCamp.org </a>
                <span>36K Views • 1 Day Ago</span>
              </div>
            </div>
          </div>

          <div class="video">
            <div class="video__thumbnail">
               <a href="https://youtube.com/shorts/A1dGPTTBxjU?si=Er5NMu9etgJfBdJz"><img src="https://img.youtube.com/vi/PpXUTUXU7Qc/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img src="http://aninex.com/images/srvc/web_de_icon.png" alt="" />
              </div>
              <div class="title">
                <h3>
                  Top 5 Programming Languages to Learn in 2021 | Best Programming Languages to Learn
                </h3>
                <a href="">FutureCoders</a>
                <span>10M Views • 3 Months Ago</span>
              </div>
            </div>
          </div>

          <div class="video">
            <div class="video__thumbnail">
               <a href="https://youtube.com/shorts/gLdBFb5pkJU?si=3SPMP1JQPcU32p4N"><img src="https://img.youtube.com/vi/YpTmcCBBdTE/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img src="http://aninex.com/images/srvc/web_de_icon.png" alt="" />
              </div>
              <div class="title">
                <h3>Build A Password Generator with React JS - Beginners Tutorial</h3>
                <a href="">FutureCoders</a>
                <span>10M Views • 3 Months Ago</span>
              </div>
            </div>
          </div>

          <div class="video">
            <div class="video__thumbnail">
               <a href="https://youtube.com/shorts/0tmfLAJFqxE?si=HrFIWG_rMg7Dc1p4"><img src="https://img.youtube.com/vi/46cXFUzR9XM/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img
                  src="https://yt3.ggpht.com/ytc/AAUvwnh53ZRIGnyzC28QrfuggCINb3cfNbNWo4Uc6qR9=s48-c-k-c0x00ffffff-no-rj"
                  alt=""
                />
              </div>
              <div class="title">
                <h3>Bella Ciao Full Song | La Casa De Papel | Money Heist | Netflix India</h3>
                <a href="">Netflix</a>
                <span>10M Views • 11 Months Ago</span>
              </div>
            </div>
          </div>

          <div class="video">
            <div class="video__thumbnail">
               <a href="https://youtu.be/GqhlnIkz8to?si=p33nzsHFhrtOuMnR"><img src="https://img.youtube.com/vi/d2na6sCyM5Q/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img
                  src="https://yt3.ggpht.com/ytc/AAUvwnhESPVEatju_1yE-03-KLeSrnSLc5yy0RcvhPd5Lg=s48-c-k-c0x00ffffff-no-rj"
                  alt=""
                />
              </div>
              <div class="title">
                <h3>DON'T EVER GIVE UP - Elon Musk (Motivational Video)</h3>
                <a href=""> Chispa Motivation</a>
                <span>10M Views • 1 Month Ago</span>
              </div>
            </div>
          </div>

          <div class="video">
            <div class="video__thumbnail">
               <a href="https://youtu.be/PImas-Jj9qQ?si=a-QsU2kAopGYULdx"><img src="https://img.youtube.com/vi/2Ji-clqUYnA/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img
                  src="https://yt3.ggpht.com/ytc/AAUvwniaHN7MZyFEiNvdHuKMzIWnDF604Z2--O4GCMq-FA=s48-c-k-c0x00ffffff-no-rj"
                  alt=""
                />
              </div>
              <div class="title">
                <h3>Javascript Fundamentals</h3>
                <a href="">Coding Addict</a>
                <span>179K • 8 Months Ago</span>
              </div>
            </div>
          </div>

          <div class="video">
            <div class="video__thumbnail">
               <a href="https://youtu.be/Y_CT-eSRrjA?si=XXohRbjtEwFeBts5"><img src="https://img.youtube.com/vi/3PHXvlpOkf4/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img
                  src="https://yt3.ggpht.com/ytc/AAUvwnifaQZvAunS0OFb2y_cieoVjLCVjqQW8Exf3BC1gg=s48-c-k-c0x00ffffff-no-rj"
                  alt=""
                />
              </div>
              <div class="title">
                <h3>Build 15 JavaScript Projects - Vanilla JavaScript Course</h3>
                <a href=""> freeCodeCamp.org </a>
                <span>470K Views • 8 Months Ago</span>
              </div>
            </div>
          </div>

          <div class="video">
            <div class="video__thumbnail">
               <a href="https://youtu.be/Aim5iuKosaE?si=fWhR9dh2tejS6Wcx"><img src="https://img.youtube.com/vi/CVClHLwv-4I/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img
                  src="https://yt3.ggpht.com/ytc/AAUvwnhIz_0Su6HhW6Ym50QCroJCAnF10X9xnnMDboN2=s48-c-k-c0x00ffffff-no-rj"
                  alt=""
                />
              </div>
              <div class="title">
                <h3>Build Real Time Face Detection With JavaScript</h3>
                <a href=""> Web Dev Simplified </a>
                <span>875K Views • 1 Year Ago</span>
              </div>
            </div>
          </div>

          <div class="video">
            <div class="video__thumbnail">
               <a href="https://youtu.be/WYn6ut_XWSk?si=uM4QcHBc0m_hAN-c"><img src="https://img.youtube.com/vi/ulprqHHWlng/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img
                  src="https://yt3.ggpht.com/ytc/AAUvwnifaQZvAunS0OFb2y_cieoVjLCVjqQW8Exf3BC1gg=s48-c-k-c0x00ffffff-no-rj"
                  alt=""
                />
              </div>
              <div class="title">
                <h3>AWS Basics for Beginners - Full Course</h3>
                <a href=""> freeCodeCamp.org </a>
                <span>36K Views • 1 Day Ago</span>
              </div>
            </div>
          </div>

          <div class="video">
            <div class="video__thumbnail">
               <a href="https://youtu.be/a4pi2zKbf8Q?si=j9IoASaEmrAqRf2z"><img src="https://img.youtube.com/vi/PpXUTUXU7Qc/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img src="http://aninex.com/images/srvc/web_de_icon.png" alt="" />
              </div>
              <div class="title">
                <h3>
                  Top 5 Programming Languages to Learn in 2021 | Best Programming Languages to Learn
                </h3>
                <a href="">FutureCoders</a>
                <span>10M Views • 3 Months Ago</span>
              </div>
            </div>
          </div>

          <div class="video">
            <div class="video__thumbnail">
               <a href="https://youtu.be/9KCtZ9r4OAw?si=i4CgUdGKUgY1DZkg"><img src="https://img.youtube.com/vi/YpTmcCBBdTE/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img src="http://aninex.com/images/srvc/web_de_icon.png" alt="" />
              </div>
              <div class="title">
                <h3>Build A Password Generator with React JS - Beginners Tutorial</h3>
                <a href="">FutureCoders</a>
                <span>10M Views • 3 Months Ago</span>
              </div>
            </div>
          </div>

          <div class="video">
            <div class="video__thumbnail">
               <a href="https://youtu.be/GO-czL8-WqU?si=ExT1hAlfArMFm0ec"><img src="https://img.youtube.com/vi/46cXFUzR9XM/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img
                  src="https://yt3.ggpht.com/ytc/AAUvwnh53ZRIGnyzC28QrfuggCINb3cfNbNWo4Uc6qR9=s48-c-k-c0x00ffffff-no-rj"
                  alt=""
                />
              </div>
              <div class="title">
                <h3>Bella Ciao Full Song | La Casa De Papel | Money Heist | Netflix India</h3>
                <a href="">Netflix</a>
                <span>10M Views • 11 Months Ago</span>
              </div>
            </div>
          </div>

          <div class="video">
            <div class="video__thumbnail">
               <a href="https://youtu.be/d68l6CRI0fM?si=CWtrJs2gZxuwzqaM"><img src="https://img.youtube.com/vi/d2na6sCyM5Q/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img
                  src="https://yt3.ggpht.com/ytc/AAUvwnhESPVEatju_1yE-03-KLeSrnSLc5yy0RcvhPd5Lg=s48-c-k-c0x00ffffff-no-rj"
                  alt=""
                />
              </div>
              <div class="title">
                <h3>DON'T EVER GIVE UP - Elon Musk (Motivational Video)</h3>
                <a href=""> Chispa Motivation</a>
                <span>10M Views • 1 Month Ago</span>
              </div>
            </div>
          </div>

          <div class="video">
            <div class="video__thumbnail">
               <a href="https://youtu.be/VDFys9V9poQ?si=bAOIlViZ0LKnkSBp"><img src="https://img.youtube.com/vi/2Ji-clqUYnA/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img
                  src="https://yt3.ggpht.com/ytc/AAUvwniaHN7MZyFEiNvdHuKMzIWnDF604Z2--O4GCMq-FA=s48-c-k-c0x00ffffff-no-rj"
                  alt=""
                />
              </div>
              <div class="title">
                <h3>Javascript Fundamentals</h3>
                <a href="">Coding Addict</a>
                <span>179K • 8 Months Ago</span>
              </div>
            </div>
          </div>

          <div class="video">
            <div class="video__thumbnail">
               <a href="https://youtu.be/2XkyQvE5VMk?si=yr4sh29xDUPuqKg3"><img src="https://img.youtube.com/vi/3PHXvlpOkf4/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img
                  src="https://yt3.ggpht.com/ytc/AAUvwnifaQZvAunS0OFb2y_cieoVjLCVjqQW8Exf3BC1gg=s48-c-k-c0x00ffffff-no-rj"
                  alt=""
                />
              </div>
              <div class="title">
                <h3>Build 15 JavaScript Projects - Vanilla JavaScript Course</h3>
                <a href=""> freeCodeCamp.org </a>
                <span>470K Views • 8 Months Ago</span>
              </div>
            </div>
          </div>

          <div class="video">
            <div class="video__thumbnail">
               <a href="https://youtu.be/Lw60SJ0AtJo?si=aXyJtz_i-jaE1ZRp"><img src="https://img.youtube.com/vi/CVClHLwv-4I/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img
                  src="https://yt3.ggpht.com/ytc/AAUvwnhIz_0Su6HhW6Ym50QCroJCAnF10X9xnnMDboN2=s48-c-k-c0x00ffffff-no-rj"
                  alt=""
                />
              </div>
              <div class="title">
                <h3>Build Real Time Face Detection With JavaScript</h3>
                <a href=""> Web Dev Simplified </a>
                <span>875K Views • 1 Year Ago</span>
              </div>
            </div>
          </div>

          <div class="video">
            <div class="video__thumbnail">
              <a href="https://youtu.be/rA5rn7_mqxU?si=kvGGbs0VRIUutoKR"><img src="https://img.youtube.com/vi/ulprqHHWlng/maxresdefault.jpg" alt="" /></a>
            </div>
            <div class="video__details">
              <div class="author">
                <img
                  src="https://yt3.ggpht.com/ytc/AAUvwnifaQZvAunS0OFb2y_cieoVjLCVjqQW8Exf3BC1gg=s48-c-k-c0x00ffffff-no-rj"
                  alt=""
                />
              </div>
              <div class="title">
                <h3>AWS Basics for Beginners - Full Course</h3>
                <a href=""> freeCodeCamp.org </a>
                <span>36K Views • 1 Day Ago</span>
              </div>
            </div>
          </div>
        </div>
      </div>

   </div>
</section>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script> 
         $(document).ready(function(){
  
  $('.acto').click(function(){
    $('.offscreen-nav').toggleClass('toggle-nav');
  });
  
});
  
<\/script>

</body>
</html>
`);
}
function hovk(){
document.write(`
	<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Youtube</title>
     <meta charset="UTF-8">
    <title>youtube clone</title>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Material Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" />
    <!-- CSS File -->
    
    <title>Final - Youtube UI Clone</title>
  <style>
    *{
        margin:0px;
        padding:0px;
        box-sizing:border-box;
    } 
    html {
  height:100%;
}
body {
  height: 4000px;
}
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 70px;
  padding: 15px;
  background-color:#fff;
  z-index:999;
  position:sticky;
  top:0;
}

.header__left {
  position:relative;
  display: flex;
  align-items: center;
}

.header__left img {
  width: 100px;
  margin-left: 15px;
}

.header i {
  padding: 0 7px;
  cursor: pointer;
}

.header__search form {
  border: 1px solid #ddd;
  height: 35px;
  margin: 0;
  padding: 0;
  border-radius:20px;
  display: flex;
}

.header__search input {
  width: 500px;
  padding: 10px;
  margin: 0;
  border-radius:20px;
  border: none;
  height: 100%;
}

.header__search button {
  padding: 0;
  margin: 0;
  height: 100%;
  border: none;
  border-radius:0 20px 20px 0;
  background-color:none;
}
/* Horizontal Chips Bar */
.context{
  position:fixed;
  height:600px;
  width:100%;
}
.chips-bar {
    background-color:#fff;
    padding: 10px 20px;
    border-bottom: 1px solid #303030;
    z-index: 999;
    position:fixed;
    top:90;
}

.chips-container {
    display: flex;
    gap: 10px;
    overflow-x: auto;
    -ms-overflow-style: none; /* IE and Edge */
    scrollbar-width: none; /* Firefox */
}

.chips-container::-webkit-scrollbar {
    display: none; /* Chrome, Safari, Opera*/
}

.chip {
    background-color:#e5e5e5;
    color:#000;
    padding: 8px 12px;
    border-radius: 8px;
    cursor: pointer;
    white-space: nowrap;
    transition: background-color 0.2s;
}

.chip:hover {
    background-color:#fff;
}

.chip.active {
    background-color:#000;
    color: #fff;
}
    .code{
  display:none;
}

.offscreen-nav {
  position:absolute;
  width: 20rem;
  overflow: hidden;
  height:100vh;
  -webkit-transform: translate3d(-20rem,0,0);
  transform: translate3d(-20rem,0,0);
  -webkit-transition: -webkit-all 600ms ease;
  transition: all 600ms ease;
}

.mainBody {
  position:relative;
  height: calc(100vh - 70px);
  display: flex;
  overflow: hidden;
}
.toggle-nav {
  -webkit-transform: translate3d(0,0,0);
  transform: translate3d(0,0,0);
}

.sidebar {
  height: 100%;
  width: 230px;
  background-color: white;
  overflow-y: scroll;
}

.sidebar__categories {
  width: 100%;
  display: flex;
  flex-direction: column;
  margin-bottom: 15px;
  margin-top: 15px;
}

.sidebar__category {
  display: flex;
  align-items: center;
  padding: 12px 25px;
}

.sidebar__category span {
  margin-left: 15px;
}

.sidebar__category:hover {
  background: #e5e5e5;
  cursor: pointer;
}

.sidebar::-webkit-scrollbar {
  display: none;
}

hr {
  height: 1px;
  background-color: #e5e5e5;
  border: none;
}

.vidasa{
  position: fixed;
  height:400px;
  width:1800px;
  z-index: -100;
  background-size: cover;
  overflow-y:scroll;
  transform: translateX(-50%);
  left:28%;
  top:170px;
}

 .works{
      width:100%;
      height:600px;
      z-index:-10;
    
    }
    .toko{
      position:absolute;
      width:800px;
      overflow-y:auto;
       z-index:-10;
    }
    .toko::-webkit-scrollbar {
    display:none;
   }
   .toko .main-video video{
     height:400px;
     width:670px;
     border-radius:20px;
     margin-left:50px;
   }
   .toko .main-video .title {
  color: #333;
  font-size: 23px;
  padding-top: 15px;
  padding-bottom: 15px;
}
  .toko .watch{
    height:100px;
    width:100%;
    display:flex;
    padding:10px;
    gap:20px;
    
  }
  .toko .watch .channel-logo{
  height:50px;
  width:50px;
  background-size:cover;
  border-radius:50%;
  border:1px solid black;
   cursor:pointer;
  }
  .toko .watch .channel-name{
    margin-top:10px;
  }
  .toko .watch .channel-subscribe{
    height:35px;
    width:110px;
    background-color:black;
    color:#fff;
    border-radius:20px;
    border:none;
    margin-top:5px;
    cursor:pointer;
  }
  .toko .watch .channel-like{
    height:35px;
    width:110px;
    background-color:#e5e5e5;
    border-radius:20px;
    border:none;
    margin-top:5px;
    display:flex;
    gap:50px;
    padding-top:8px;
     padding-left:10px;
    cursor:pointer;
  }
 .toko .watch .channel-like p{
   position:absolute;
   margin-left:45px;
   color:black;
   margin-top:-16px;
  }
 .toko .watch .channel-share{
    height:35px;
    width:110px;
    background-color:#e5e5e5;
    border-radius:20px;
    border:none;
    margin-top:5px;
    display:flex;
     padding-left:20px;
    padding-top:8px;
    gap:10px;
 }
.toko .watch .channel-download{
    height:35px;
    width:110px;
    background-color:#e5e5e5;
    border-radius:20px;
    border:none;
    margin-top:5px;
    display:flex;
     padding-left:6px;
    padding-top:8px;
    gap:5px;
}
.toko .watch .channel-save{
    height:35px;
    width:80px;
    background-color:#e5e5e5;
    border-radius:20px;
    border:none;
    margin-top:5px;
    display:flex;
     padding-left:6px;
    padding-top:8px;
    gap:5px;
}
.toko .watch .channel-book{
    height:35px;
    width:35px;
    background-color:#e5e5e5;
    border-radius:50%;
    border:none;
    margin-top:5px;
    display:flex;
     padding-left:7px;
    padding-top:8px;
    gap:5px;
}

  .toko .description {
    height:100px;
    width:100%;
    
  }
  .toko .description .description-box{
     border-radius:20px;
    height:80px;
    width:700px;
    margin-left:30px;
    background-color:#e5e5e5;

  }
  
     .vio-os{  
      position:fixed;
      height:1100px;
      width:500px;
      overflow:auto;
      margin-left:800px;
      overflow-y:scroll;
      top:150px;
    }

    .vio-os::-webkit-scrollbar {
    display:none;
  }
  .chipo{
    background-color:#fff;
    padding: 10px 20px;
    position:sticky;
    top:0;
    z-index:99;
}
 .chipko {
    display: flex;
    gap: 10px;
    overflow-x: auto;
    -ms-overflow-style: none; /* IE and Edge */
    scrollbar-width: none; /* Firefox */
}
.chipko::-webkit-scrollbar {
    display: none; /* Chrome, Safari, Opera*/
}

.chips{
    background-color:#e5e5e5;
    color:#000;
    padding: 8px 12px;
    border-radius: 8px;
    cursor: pointer;
    white-space: nowrap;
    transition: background-color 0.2s;
}

.chips:hover {
    background-color:#fff;
}
.chips.activo {
    background-color:#000;
    color: #fff;
}
.video-list .vid {
  display: flex;
  align-items: center;
  gap: 15px;
  border-radius: 5px;
  margin: 10px;
  padding: 5px;
  border: 1px solid rgba(0,0,0,.1);
  cursor: pointer;
}
.vid{
  position:relative;
}
.vid:active{
  background: #f7f7f7;
}
.video-list .vid video{
  height:150px;
  width:180px;
  border-radius:30px;
 
}
h3{
 margin-left:30px;
  width:750px;
}
h4{
  width:250px;
  position:absolute;
  margin-left:200px;
  margin-top:-80px;
  font-size:15px;
}
.channel{
  position:absolute;
  margin-left:200px;
  font-size:15px;
}
.view{
  position:absolute;
  margin-left:200px;
  margin-top:60px;
  font-size:15px;
}
#fav{
   position:absolute;
   margin-left:440px;
   margin-top:-60px;
}
.comment{
  margin-top:720px;
  position:absolute;
  height:400px;
  width:800px;
   overflow-y:scroll;
}
.comment::-webkit-scrollbar {
    display: none; /* Chrome, Safari, Opera*/
  :
}

 .comment .comment-ie{
  margin-top:50px;
  height:50px;
  width:50px;
  border:1px solid black;
  border-radius:50%;
  position:absolute;
  margin-left:20px;
}
 .comment .comment-box{
  margin-top:50px;
  position:absolute;
  margin-left:80px;
  height:50px;
  width:650px;
}
 .comment .comment-heading{
  position:absolute;
  display:flex;
  margin-left:20px;
  
 }
 .comment .comment-heading i{
  margin-top:10px;
  outline:none;
  padding-left:10px;
 }
 .comment .comment-heading {
  position:sticky;
   top:0;

 }
 .comment-input{
   position:sticky;
   top:0;

 }
 .comment  #postBtn{
  margin-top:120px;
  margin-left:600px;
  padding: 8px 16px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
 }
 .comment-item {
  
  padding: 10px;
  border-bottom: 1px solid #eee;
  margin-top: 10px;
  border-radius: 4px;
 margin-left:20px;

}

     </style>
    </head>
    <body> 
  <!-- Header Starts -->
    <div class="header">
      <div class="header__left" id="cod">
        <i id="menu" class="material-icons acto">menu</i> 
      </div>
      <div class="header__search">
        <form action="">
          <input type="text" placeholder="Search" />
          <button><i class="material-icons">search</i></button>
        </form>
      </div>

      <div class="header__icons">
        <i class="material-icons display-this">search</i>
        <i class="material-icons">videocam</i>
        <i class="material-icons">apps</i>
        <i class="material-icons">notifications</i>
        <i class="material-icons display-this">account_circle</i>
      </div>
    </div>  
    <nav class="chips-bar">
            <div class="chips-container">
                <span class="chip active">All</span>
                <span class="chip">short</span>
                <span class="chip">video</span>
                <span class="chip">Music</span>
                <span class="chip">Android</span>
                <span class="chip">Gaming</span>
                <span class="chip">Live</span>
                <span class="chip">Vlog</span>
                <span class="chip">Movies</span>
                <span class="chip">Programming</span>
                <span class="chip">Technology</span>
                <span class="chip">News</span>
            </div>
        </nav>
    <section class="context">
     <div class="offscreen-nav">
  <div class="mainBody">
      <!-- Sidebar Starts -->
      <div class="sidebar">
        <div class="sidebar__categories">
          <div class="sidebar__category">
            <i class="material-icons">home</i>
            <span>Home</span>
          </div>
          <div class="sidebar__category">
            <i class="material-icons">local_fire_department</i>
            <span>Trending</span>
          </div>
          <div class="sidebar__category">
            <i class="material-icons">subscriptions</i>
            <span>Subcriptions</span>
          </div>
        </div>
        <hr />
        <div class="sidebar__categories">
          <div class="sidebar__category">
            <i class="material-icons">library_add_check</i>
            <span>Library</span>
          </div>
          <div class="sidebar__category">
            <i class="material-icons">history</i>
            <span>History</span>
          </div>
          <div class="sidebar__category">
            <i class="material-icons">play_arrow</i>
            <span>Your Videos</span>
          </div>
          <div class="sidebar__category">
            <i class="material-icons">watch_later</i>
            <span>Watch Later</span>
          </div>
          <div class="sidebar__category">
            <i class="material-icons">thumb_up</i>
            <span>Liked Videos</span>
          </div>
        </div>
      </div>
        <hr/>
      </div>
      </div>
      </section> 
      
       <section class="vidaa"> 
         <video  class="vidasa active" id="video" src="gta.mp4"></video>
       </section>
      <div class="vio-os">
      <div class="video-list">
          <nav class="chipo">
            <div class="chipko">
                <span class="chips activo">All</span>
                <span class="chips">short</span>
                <span class="chips">video</span>
                <span class="chips">Music</span>
                <span class="chips">Android</span>
                <span class="chips">Gaming</span>
                <span class="chips">Live</span>
                <span class="chips">Vlog</span>
                <span class="chips">Movies</span>
                <span class="chips">Programming</span>
                <span class="chips">Technology</span>
                <span class="chips">News</span>
            </div>
        </nav>
        <section class="vees">
      <div class="vid active">
      <video src ="hi.mp4" muted></video>
      <h4 class="title">Build A Password Generator with React JS - Beginners Tutorial</h4>
      <p class="channel">Australian Indian Orchestra</p>
      <p class="view">8 million view . 1 week <i class="fa fa-ellipsis-v" id="fav" aria-hidden="true"></i></p>
     
    </div>
      <div class="vid">
      <video src ="uso.mp4" muted></video>
      <h4 class="title">Build A Password Generator with React JS - Beginners Tutorial</h4>
      <p class="channel">Australian Indian Orchestra</p>
      <p class="view">8 million view . 1 week <i class="fa fa-ellipsis-v" id="fav" aria-hidden="true"></i></p>
      
    </div>
    <div class="vid">
     <video src ="hi.mp4" muted></video>
     <h4 class="title">Build A Password Generator with React JS - Beginners Tutorial</h4>
      <p class="channel">Australian Indian Orchestra</p>
      <p class="view">8 million view . 1 week <i class="fa fa-ellipsis-v" id="fav" aria-hidden="true"></i></p>
     
    </div>
    <div class="vid">
      <video src ="wwe.mp4" muted></video>
      <h4 class="title">Build A Password Generator with React JS - Beginners Tutorial</h4>
      <p class="channel">Australian Indian Orchestra</p>
      <p class="view">8 million view . 1 week <i class="fa fa-ellipsis-v" id="fav" aria-hidden="true"></i></p>
     

    </div>
    <div class="vid">
      <video src ="gta.mp4" muted></video>
      <h4 class="title">Build A Password Generator with React JS - Beginners Tutorial</h4>
      <p class="channel">Australian Indian Orchestra</p>
      <p class="view">8 million view . 1 week <i class="fa fa-ellipsis-v" id="fav" aria-hidden="true"></i></p>
      
    </div>
    <div class="vid">
      <video src ="hi.mp4" muted></video>
     <h4 class="title">Build A Password Generator with React JS - Beginners Tutorial</h4>
      <p class="channel">Australian Indian Orchestra</p>
      <p class="view">8 million view . 1 week <i class="fa fa-ellipsis-v" id="fav" aria-hidden="true"></i></p>
     
    </div>
    <div class="vid">
     <video src ="hi.mp4" muted></video>
      <h4 class="title">Build A Password Generator with React JS - Beginners Tutorial</h4>
      <p class="channel">Australian Indian Orchestra</p>
      <p class="view">8 million view . 1 week <i class="fa fa-ellipsis-v" id="fav" aria-hidden="true"></i></p>
      <
    </div>
    <div class="vid">
      <video src ="hi.mp4" muted></video>
     <h4 class="title">Build A Password Generator with React JS - Beginners Tutorial</h4>
      <p class="channel">Australian Indian Orchestra</p>
      <p class="view">8 million view . 1 week <i class="fa fa-ellipsis-v" id="fav" aria-hidden="true"></i></p>
      
    </div>
    <div class="vid">
    <video src ="gta.mp4" muted></video>
      <h4 class="title">Build A Password Generator with React JS - Beginners Tutorial</h4>
      <p class="channel">Australian Indian Orchestra</p>
      <p class="view">8 million view . 1 week <i class="fa fa-ellipsis-v" id="fav" aria-hidden="true"></i></p>   
    </div>
      </div>
   </div>

       
      </section>

    
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"> script</script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
     <script> 
     $(document).ready(function(){
  
  $('.acto').click(function(){
    $('.offscreen-nav').toggleClass('toggle-nav');
  });
  
});
        function scrollVideo() {
  var video = $('#video').get(0),
    videoLength = video.duration,
    scrollPosition = $(document).scrollTop();
  
  video.currentTime = (scrollPosition / ($(document).height() - $(window).height())) * videoLength;
}

$(window).scroll(function(e) {
  scrollVideo();
});

let mainVideo = document.querySelector('.vidasa');
 let listVideo = document.querySelectorAll('.vid');

 listVideo.forEach(video =>{
  video.onclick = () =>{
    listVideo.forEach(vid => vid.classList.remove('active'));
    video.classList.add('active');
    if(video.classList.contains('active')){
      let src = video.children[0].getAttribute('src');
       mainVideo.src = src;
    };
  };
});
<\/script>

</body>
</html>
`);
}

function shot(){
document.write(`
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<title>youtube clone</title>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Material Icons -->

    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" />
    <!-- CSS File -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
   
    <title>Final - Youtube UI Clone</title>
    <style>
    
@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap');

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Roboto', sans-serif;
}
/* header */

.material-icons {
  color: rgb(96, 96, 96);
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  position:sticky;
  top:0px;
  height: 70px;
  padding: 15px;
  background-color:#fff;
  z-index:999;
}

.header__left {
  position:relative;
  display: flex;
  align-items: center;
}

.header__left img {
  width: 100px;
  margin-left: 15px;
}

.header i {
  padding: 0 7px;
  cursor: pointer;
}

.header__search form {
  border: 1px solid #ddd;
  height: 35px;
  margin: 0;
  padding: 0;
  border-radius:20px;
  display: flex;
}

.header__search input {
  width: 500px;
  padding: 10px;
  margin: 0;
  border-radius:20px;
  border: none;
  height: 100%;
}

.header__search button {
  padding: 0;
  margin: 0;
  height: 100%;
  border: none;
  border-radius:0 20px 20px 0;
  background-color:none;
}
.offscreen-nav {
  position:absolute;
  width: 20rem;
  overflow: hidden;
  height:100vh;
  -webkit-transform: translate3d(-20rem,0,0);
  transform: translate3d(-20rem,0,0);
  -webkit-transition: -webkit-all 600ms ease;
  transition: all 600ms ease;
}

.mainBody {
  position:relative;
  height: calc(100vh - 70px);
  display: flex;
  overflow: hidden;
}
.toggle-nav {
  -webkit-transform: translate3d(0,0,0);
  transform: translate3d(0,0,0);
}

.sidebar {
  height: 100%;
  width: 230px;
  background-color: white;
  overflow-y: scroll;
}

.sidebar__categories {
  width: 100%;
  display: flex;
  flex-direction: column;
  margin-bottom: 15px;
  margin-top: 15px;
}

.sidebar__category {
  display: flex;
  align-items: center;
  padding: 12px 25px;
}

.sidebar__category span {
  margin-left: 15px;
}

.sidebar__category:hover {
  background: #e5e5e5;
  cursor: pointer;
}

.sidebar::-webkit-scrollbar {
  display: none;
}

hr {
  height: 1px;
  background-color: #e5e5e5;
  border: none;
}
.videos {
  background-color: #f9f9f9;
  width:100%;
  height: 600px;
  padding: 15px 15px;
  border-top: 1px solid #ddd;
  overflow-y: scroll;
}

.videos__container {
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  flex-wrap: wrap;
}

.video {
  width: 310px;
  margin-bottom: 30px;
}

.video__thumbnail {
  width: 100%;
  height: 170px;
  border-radius:20px;
}

.video__thumbnail img {
  object-fit: cover;
  height: 100%;
  width: 100%;
  border-radius:20px;
}


.author img {
  object-fit: cover;
  border-radius: 50%;
  height: 40px;
  width: 40px;
  margin-right: 10px;
}

.video__details {
  display: flex;
  margin-top: 10px;
}

.title {
  display: flex;
  flex-direction: column;
}

.title h3 {
  color: rgb(3, 3, 3);
  line-height: 18px;
  font-size: 14px;
  margin-bottom: 6px;
}

.title a,
span {
  text-decoration: none;
  color: rgb(96, 96, 96);
  font-size: 14px;
}

h1 {
  font-size: 20px;
  margin-bottom: 10px;
  color: rgb(3, 3, 3);
}

@media (max-width: 425px) {
  .header__search {
    display: none;
  }

  .header__icons .material-icons {
    display: none;
  }

  .header__icons .display-this {
    display: inline;
  }

  .sidebar {
    display: none;
  }
}
.reel__container {
  height: 529.76px;
  width: 354.24px;
  background-size: cover;
  border-radius: 10px;
  padding: 1rem;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
  margin-top:20px;
  margin-left:450px;

}
.app-container {
    width:1000px;/* Simulates mobile screen on desktop */
    height: 100vh;
    overflow-y: scroll;
    margin-left:150px;
    scroll-snap-type: y mandatory; 
    /* Hides the scrollbar for a cleaner look */
    scrollbar-width: none; /* Firefox */
}

.app-container::-webkit-scrollbar {
    display: none; /* Chrome, Safari, Opera */
}

.video-container {
    position: relative;
    height: 550px;
    width: 400px;
    scroll-snap-align: start; /* Snaps exactly to the top of this container */
    background-color: #111;
    line-height:30px;
    margin-left:300px;
    margin-top:20px;
    border-radius: 20px;
   box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
}


.short-video {
    width: 100%;
    height: 100%;
    object-fit: cover; /* Ensures the video fills the screen without stretching */
    cursor: pointer;
}
#long-vid{
  height:200px;
  width:100%;
  margin-top:150px;
}
/* Gradient shadow at the bottom so white text is readable */
.controls-overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    padding: 20px 15px;
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    background: linear-gradient(to top, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0) 100%);
    color: white;
    pointer-events: none; /* Allows clicking the video behind the overlay */
}

.video-info {
    flex: 1;
    padding-right: 20px;
    pointer-events: auto; /* Re-enable clicks for text area */
}

.video-info h3 {
    font-size: 16px;
    margin-bottom: 8px;
}

.video-info p {
    font-size: 14px;
    line-height: 1.4;
    font-weight: 300;
}

.action-buttons {
    position:relative;
    display: flex;
    flex-direction: column;
    gap: 25px;
    pointer-events: auto; /* Re-enable clicks for buttons */
    left:80px;
    top:-50px;
}

.action-btn {
    background: none;
    border: none;
    color:black;
    display: flex;
    flex-direction: column;
    align-items: center;
    cursor: pointer;
    font-size: 28px; /* For emojis used as icons */
    transition: transform 0.2s ease;
}

.action-btn:active {
    transform: scale(0.9);
}

.action-btn span {
    font-size: 13px;
    margin-top: 8px;
    font-weight: 600;
}
.subsa{
  position:relative;
  display:flex;
  gap:10px;
 
}
.loko{
  height:50px;
  width:50px;
  border-radius:50%;
  border:1px solid #fff;
  margin-top:-20px;
}
.subsi{
  height:30px;
  width:100px ;
  background-color:#e5e5e5;
  color:#000;
  border-radius:20px;
  border:none;
  cursor:pointer;

}
.mus{
  height:50px;
  width:50px ;
  border-radius:10px;
  border:1px solid #ddd;
}
    </style>
</head>
<body>
	<!-- Header Starts -->
    <div class="header">
      <div class="header__left" id="cod">
        <i id="menu" class="material-icons acto">menu</i> 
      </div>
      <div class="header__search">
        <form action="">
          <input type="text" placeholder="Search" />
          <button><i class="material-icons">search</i></button>
        </form>
      </div>

      <div class="header__icons">
        <i class="material-icons display-this">search</i>
        <i class="material-icons">videocam</i>
        <i class="material-icons">apps</i>
        <i class="material-icons">notifications</i>
        <i class="material-icons display-this">account_circle</i>
      </div>
    </div>  
      <section class="context">
     <div class="offscreen-nav">
  <div class="mainBody">
      <!-- Sidebar Starts -->
      <div class="sidebar">
        <div class="sidebar__categories">
          <div class="sidebar__category">
            <i class="material-icons">home</i>
            <span>Home</span>
          </div>
          <div class="sidebar__category">
            <i class="material-icons">local_fire_department</i>
            <span>Trending</span>
          </div>
          <div class="sidebar__category">
            <i class="material-icons">subscriptions</i>
            <span>Subcriptions</span>
          </div>
        </div>
        <hr />
        <div class="sidebar__categories">
          <div class="sidebar__category">
            <i class="material-icons">library_add_check</i>
            <span>Library</span>
          </div>
          <div class="sidebar__category">
            <i class="material-icons">history</i>
            <span>History</span>
          </div>
          <div class="sidebar__category">
            <i class="material-icons">play_arrow</i>
            <span>Your Videos</span>
          </div>
          <div class="sidebar__category">
            <i class="material-icons">watch_later</i>
            <span>Watch Later</span>
          </div>
          <div class="sidebar__category">
            <i class="material-icons">thumb_up</i>
            <span>Liked Videos</span>
          </div>
        </div>
      </div>
        <hr/>
      </div>
</div>
<section class="reel">
 <div class="app-container">
        
        <div class="video-container">
            <video class="short-video" src="https://www.w3schools.com/html/mov_bbb.mp4" loop playsinline></video>
            
            <div class="controls-overlay">
                <div class="video-info">
                   <div class="subsa">
                    <div class="loko"> 
                    </div><h3>@ui_designer</h3>
                    <button class="subsi">subscribe</button>
                    </div>
                    <p>Building a shorts clone with vanilla web tech! 🚀 #coding #webdev</p>
                </div>
                <div class="action-buttons">
                    <button class="action-btn"><i class="fa fa-thumbs-up" aria-hidden="true"></i><span>12K</span></button>
                    <button class="action-btn"><i class="fa fa-thumbs-down" aria-hidden="true"></i><span>450</span></button>
                    <button class="action-btn"><i class="fa fa-comments" aria-hidden="true"></i><span>comment</span></button>
                    <button class="action-btn"><i class="fa fa-share-square" aria-hidden="true"></i><span>Share</span></button>
                   <div class="mus"></div>
                </div>
            </div>

        </div>

        <div class="video-container">
            <video class="short-video" src="uso.mp4" loop playsinline></video>
            
            <div class="controls-overlay">
                <div class="video-info">
                  <div class="subsa">
                    <div class="loko"> 
                    </div><h3>@ui_designer</h3>
                    <button class="subsi">subscribe</button>
                    </div>
                    <p>CSS scroll snapping is absolute magic ✨ #css #frontend</p>
                </div>
                <div class="action-buttons">
                    <button class="action-btn"><i class="fa fa-thumbs-up" aria-hidden="true"></i><span>12K</span></button>
                    <button class="action-btn"><i class="fa fa-thumbs-down" aria-hidden="true"></i><span>450</span></button>
                    <button class="action-btn"><i class="fa fa-comments" aria-hidden="true"></i><span>comment</span></button>
                    <button class="action-btn"><i class="fa fa-share-square" aria-hidden="true"></i><span>Share</span></button>
                    <div class="mus"></div>
                </div>
            </div>
        </div>

       <div class="video-container">
            <video class="short-video" id="long-vid"src="gta.mp4" loop playsinline></video>
            
            <div class="controls-overlay">
                <div class="video-info">
                   <div class="subsa">
                    <div class="loko"> 
                    </div><h3>@ui_designer</h3>
                    <button class="subsi">subscribe</button>
                    </div>
                    <p>CSS scroll snapping is absolute magic ✨ #css #frontend</p>
                </div>
                <div class="action-buttons">
                   <button class="action-btn"><i class="fa fa-thumbs-up" aria-hidden="true"></i><span>12K</span></button>
                    <button class="action-btn"><i class="fa fa-thumbs-down" aria-hidden="true"></i><span>450</span></button>
                    <button class="action-btn"><i class="fa fa-comments" aria-hidden="true"></i><span>comment</span></button>
                    <button class="action-btn"><i class="fa fa-share-square" aria-hidden="true"></i><span>Share</span></button>
                    <div class="mus"></div>
                </div>
            </div>
        </div>
       
        <div class="video-container">
            <video class="short-video" id="long-vid"src="wwe.mp4" loop playsinline></video>
            
            <div class="controls-overlay">
                <div class="video-info">
                   <div class="subsa">
                    <div class="loko"> 
                    </div><h3>@ui_designer</h3>
                    <button class="subsi">subscribe</button>
                    </div>
                    <p>CSS scroll snapping is absolute magic ✨ #css #frontend</p>
                </div>
                <div class="action-buttons">
                   <button class="action-btn"><i class="fa fa-thumbs-up" aria-hidden="true"></i><span>12K</span></button>
                    <button class="action-btn"><i class="fa fa-thumbs-down" aria-hidden="true"></i><span>450</span></button>
                    <button class="action-btn"><i class="fa fa-comments" aria-hidden="true"></i><span>comment</span></button>
                    <button class="action-btn"><i class="fa fa-share-square" aria-hidden="true"></i><span>Share</span></button>
                   <div class="mus"></div>

                </div>
            </div>
        </div>

    </div>
</section>

 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script> 
         $(document).ready(function(){
  
  $('.acto').click(function(){
    $('.offscreen-nav').toggleClass('toggle-nav');
  });
  
});


          document.addEventListener("DOMContentLoaded", () => {
    const videos = document.querySelectorAll('.short-video');

    // 1. Play/Pause when the user taps the video
    videos.forEach(video => {
        video.addEventListener('click', () => {
            if (video.paused) {
                video.play();
            } else {
                video.pause();
            }
        });
    });

    // 2. Set up the Intersection Observer to handle scroll autoplay
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.7 // 70% of the video must be visible to trigger
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // Video is in view, play it
                entry.target.play().catch(err => {
                    // Catch autoplay restrictions (browsers usually require initial user interaction)
                    console.log("Autoplay prevented by browser. User must interact first.");
                });
            } else {
                // Video is out of view, pause it and reset to beginning
                entry.target.pause();
                entry.target.currentTime = 0; 
            }
        });
    }, observerOptions);

    // Attach the observer to every video element
    videos.forEach(video => {
        observer.observe(video);
    });
});
   

<\/script>

</body>
</html>
`);
}
