#include<stdio.h>
#include<conio.h>
void main(){

	int i,j,n;
	printf("choose your number");
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		for(j=1;j<=i;j++)
		{
			printf("like and subscribe");
		}
		printf("\n");
	}
}
