#define RAJU 100
void tech(){
#ifdef RAJU
printf("RAJU is defined. So, this line will be added in this C file\n");
#else
printf("RAJU is not defined\n");
#endif
}

