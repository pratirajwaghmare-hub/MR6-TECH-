#include <iostream>
using namespace std;
 main()
{
 // Local variable declaration:
 //do while loop project tutorial
 string name;
 cout<<"enter your name";
 cin<<&name;
 do
 {
 	cout<<name;
   	
 }while(name!="modi");
}

