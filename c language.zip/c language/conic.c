#include<stdio.h>
 #define a 30
 #define b 20
 void main(){
 	#if(a==b)
 	 printf("equal number");
 	#elif(a<b)
 	  printf("a is geather thar b");
 	#elif(a>b)
 	 printf("b is greather than a");
 	#else 
 	  printf("not equal number");
 	#endif
 }
