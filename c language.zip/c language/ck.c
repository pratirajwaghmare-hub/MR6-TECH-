<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Emotion Detector</title>
  <style>
    body {
      margin:0;
      display:flex;
      justify-content:center;
      align-items:center;
      height:100vh;
      background:#0d1117;
      color:white;
      font-family:Arial, sans-serif;
    }
    .stage {
      position:relative;
    }
    video, canvas {
      border-radius:10px;
    }
    video {
      transform: scaleX(-1); /* mirror video */
    }
    canvas {
      position:absolute;
      left:0; top:0;
      pointer-events:none;
    }
    #status {
      margin-top:10px;
      text-align:center;
      font-weight:bold;
      color:#00e676;
    }
  </style>
</head>
<body>
  <div class="stage">
    <video id="video" autoplay muted playsinline width="640" height="480"></video>
    <canvas id="overlay" width="640" height="480"></canvas>
    <div id="status">Loading models...</div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/@vladmandic/face-api/dist/face-api.min.js"></script>
  <script>
    const video = document.getElementById('video');
    const canvas = document.getElementById('overlay');
    const ctx = canvas.getContext('2d');
    const statusEl = document.getElementById('status');

    async function start() {
      // Load all required models from CDN
      await faceapi.nets.tinyFaceDetector.loadFromUri('https://cdn.jsdelivr.net/npm/@vladmandic/face-api/model/');
      await faceapi.nets.faceLandmark68TinyNet.loadFromUri('https://cdn.jsdelivr.net/npm/@vladmandic/face-api/model/');
      await faceapi.nets.faceExpressionNet.loadFromUri('https://cdn.jsdelivr.net/npm/@vladmandic/face-api/model/');
      statusEl.textContent = "Models loaded! Starting camera...";

      // Start camera
      const stream = await navigator.mediaDevices.getUserMedia({ video: {} });
      video.srcObject = stream;

      video.onloadedmetadata = () => {
        statusEl.textContent = "Running detection...";
        detectLoop();
      };
    }

    async function detectLoop() {
      const options = new faceapi.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.5 });

      const detections = await faceapi
        .detectAllFaces(video, options)
        .withFaceLandmarks(true)
        .withFaceExpressions();

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      if (detections.length > 0) {
        detections.forEach(d => {
          const box = d.detection.box;
          const landmarks = d.landmarks;

          // Draw green face box
          ctx.strokeStyle = "#00ff00";
          ctx.lineWidth = 2;
          ctx.strokeRect(canvas.width - box.x - box.width, box.y, box.width, box.height);

          // Draw landmarks (dot-to-dot mirrored)
          ctx.fillStyle = "#ff00ff";
          landmarks.positions.forEach(p => {
            ctx.beginPath();
            ctx.arc(canvas.width - p.x, p.y, 2, 0, 2 * Math.PI);
            ctx.fill();
          });

          // Emotion
          const expr = d.expressions;
          let best = "neutral", bestVal = 0;
          for (let k in expr) {
            if (expr[k] > bestVal) { bestVal = expr[k]; best = k; }
          }
          const emotion = best.toUpperCase();

          // Draw label background
          ctx.font = "24px Arial";
          const textW = ctx.measureText(emotion).width;
          const centerX = canvas.width - (box.x + box.width / 2);
          const textX = centerX - textW / 2;
          const textY = box.y - 10;

          ctx.fillStyle = "#00ff00";
          ctx.fillRect(textX - 5, textY - 28, textW + 10, 30);

          // Draw emotion text
          ctx.fillStyle = "#000";
          ctx.fillText(emotion, textX, textY - 5);
        });
      }

      requestAnimationFrame(detectLoop);
    }

    start();
  </script>
</body>
</html>