#include <iostream>
using namespace std;
 main(){
 	/* cpp while table project loop*/
	int i,p=1;
	cout<<"enter positive number"<<endl;
    cin>>i;
	while(p<=10){
		cout<<i*p<<endl;
		p=p+1;
		
		
	}
	
	
}
/*Thanks for watching*/
